
public class Aisle {
	private int row, colLeft, colRight;
	private String name;
	
	public Aisle(String name, int row, int colLeft, int colRight) {
		this.row = row;
		this.colLeft = colLeft;
		this.colRight = colRight;
		this.name = name;
	}
	
	public int getRow() {
		return row;
	}
	
	public int getColLeft() {
		return colLeft;
	}
	
	public int getColRight() {
		return colRight;
	}
	
	public String getName() {
		return name;
	}
}
