
public class Shelf {
	private String name;
	private int posX, posY;
	private Vertice shortestA, shortestB;
}
