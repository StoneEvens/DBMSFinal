import java.util.ArrayList;

public class TestClass {
	volatile ArrayList<Integer> bestOrderEver = new ArrayList<Integer>();
	volatile double shortestDEver = 1000;
	volatile int generations = 0;
	volatile int turns = 0;
	final int Vertexes = 10;
	int ROUNDS;
	boolean determinator = true;
	
	int bruteDistance = 1000;
	
	int status = 0;
	
	public TestClass() {
		// TODO Auto-generated method stub
		//Change Here
		//ROUNDS = Vertexes;
		ROUNDS = 1;
		
		BruteForceAlgorithm bfa = new BruteForceAlgorithm(Vertexes);
		
		long start = System.currentTimeMillis();
		
		bfa.start();
		//System.out.println(String.format("Absolute Best Order: %s", bfa.start().toString()));
		//System.out.println(String.format("Shortest Distance: %.0f", bfa.shortestD));
		//System.out.println(String.format("Tried %d Orders", bfa.getCount()));
		
		bruteDistance = (int)bfa.shortestD;
		
		long end = System.currentTimeMillis();
		//System.out.println(String.format("Time Used: %s seconds", (end - start) / 1000d).toString());
		
		AverageDistanceAlgorithm ada = new AverageDistanceAlgorithm(bfa.getTargets(), bfa.getStart(), bfa.getEnd());
		
		
		start = end;
		end = System.currentTimeMillis();
		
		bestOrderEver = ada.getOrder();
		//System.out.println("Check Point");
		
		for (int i = 0; i < 1; i++) {
			turns = 0;
			
			for (int j = 0; j < ROUNDS; j++) {
				Thread thread = new Thread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						GeneticAlgorithm ga = new GeneticAlgorithm(bfa.getTargets(), bfa.getStart(), bfa.getEnd(), determinator);
						
						if (determinator) {
							for (int k = 0; k < ga.POPSIZE; k++) {
								ga.population.add(bestOrderEver);
							}
						}
						
						ga.start();
						
						if (ga.shortestD < shortestDEver) {
							shortestDEver = ga.shortestD;
							bestOrderEver = ga.bestOrder;
						}
						
						generations += ga.getGeneration();
						
						turns++;
					}
					
				});
				
				
				thread.start();
			}
			
			while (turns < ROUNDS) {
				
			}
			
			determinator = true;
		}
		
		//System.out.println(String.format("Relative Best Order: %s", bestOrderEver.toString()));
		//System.out.println(String.format("Shortest Distance: %.0f", shortestDEver));
		//System.out.println(String.format("Tried %d Generations", generations));
		
		start = end;
		end = System.currentTimeMillis();
		
		//System.out.println(String.format("Time Used: %s seconds", (end - start) / 1000d).toString());
		
		if (bruteDistance == shortestDEver) {
			System.out.println("Perfect!");
			status = 1;
		} else if (bruteDistance - shortestDEver < 2) {
			System.out.println("Great!");
			status = 2;
		} else if (bruteDistance - shortestDEver < 3) {
			System.out.println("Okay");
			status = 3;
		} else {
			System.out.println("F NO!");
			status = 4;
		}
	}
	
	public int getStatus() {
		return status;
	}
}
