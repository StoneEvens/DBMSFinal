import java.util.ArrayList;

public class RowItemAlgorithm {
	private ArrayList<Location> targets;
	
	private ArrayList<Aisle> aisles;
	
	private ArrayList<Integer> aisleOrder;
	private ArrayList<Integer> bestOrder;
	private Location start, end;
	private int compareCount;
	private double shortestD;
	
	private final int TOTALROW = 5;
	private final int TOTALCOL = 3;
	
	private ArrayList<ArrayList<Double>> distances;
	
	public RowItemAlgorithm(int count) {
		targets = new ArrayList<Location>();
		aisles = new ArrayList<Aisle>();
		aisleOrder = new ArrayList<Integer>();
		bestOrder = new ArrayList<Integer>();
		this.compareCount = 0;
		
		start = new Location(4, 2);
		end = new Location(4, 1);
		
		//Create Test Values
		for (int i = 0; i < count; i++) {
			Location lctn = new Location((int)Math.floor(Math.random()*(TOTALROW - 1)), (int)Math.floor(Math.random()*(TOTALCOL - 1)));
			targets.add(lctn);
		}
		
		//Read Targets and Create Corresponding Aisles
		for (Location lctn: targets) {
			int r = lctn.getRow();
			int c = lctn.getCol();
			
			Aisle a = new Aisle(String.format("%d%d%d", r, c, c+1), r, c, c+1);
			
			boolean exist = false;
			for (Aisle il: aisles) {
				if (!exist && il.getName() == a.getName()) {
					exist = true;
				}
			}
			
			if (!exist) {
				aisles.add(a);
			}
		}
		
		//Construct Initial Order
		for (int i = 0; i < aisles.size(); i++) {
			aisleOrder.add(i);
		}
	}
}
