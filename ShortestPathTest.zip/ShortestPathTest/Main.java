
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int totalSuccess = 0;
		int totalGood = 0;
		int totalOkay = 0;
		int totalTrial = 0;
		int status = 0;
		
		while (status < 100) {
			TestClass tc = new TestClass();
			
			switch(tc.getStatus()) {
			case 0:
				System.out.println("Failed to execute!");
				break;
			case 1:
				totalSuccess++;
				break;
			case 2:
				totalGood++;
				break;
			case 3:
				totalOkay++;
				break;
			}
			
			totalTrial++;
			//status = tc.getStatus();
			status++;
		}
		
		System.out.printf("Perfect Rate: %d Percent\n", (int)totalSuccess*100/totalTrial);
		System.out.printf("Great Rate: %d Percent\n", (int)totalGood*100/totalTrial);
		System.out.printf("Okay Rate: %d Percent\n", (int)totalOkay*100/totalTrial);
		System.out.printf("Total Trial: %d", totalTrial);
	}
}
