package TestStat;
import java.util.ArrayList;

//This class is a simulation of the data retrieved from database
//Will be replaced by Accessor in the future
public class TestStat {
	private int[] dimension;
	private ArrayList<int[]> itscs, shelves, wkwys;
	private ArrayList<String> randomShelves;
	//private ArrayList<int[]> wkwyLocation;
	
	public TestStat() {
		dimension = new int[2];
		itscs = new ArrayList<int[]>();
		shelves = new ArrayList<int[]>();
		wkwys = new ArrayList<int[]>();
		//wkwyLocation = new ArrayList<int[]>();
		
		dimension[0] = 7;
		dimension[1] = 7;
		
		for (int i = 0; i < getDimension()[0]; i++) {
			for (int j = 0; j < getDimension()[1]; j++) {
				if (i%3 == 0 || j%3 == 0) {
					if (i%3 == 0 && j%3 == 0) {
						itscs.add(new int[] {i, j});
					} else {
						wkwys.add(new int[] {i, j});
					}
				} else {
					if (i%3 == 1) {
						shelves.add(new int[] {i, j, -1, 0});
					}
					
					if (i%3 == 2) {
						shelves.add(new int[] {i, j, 1, 0});
					}
				}
			}
		}
		
		randomShelves = new ArrayList<String>();
		
		for (int i = 0; i < shelves.size(); i++) {
			randomShelves.add(String.format("S%d", i));
		}
		
		for (int i = 0; i < 100; i++) {
			int indexA = (int)Math.floor(Math.random()*randomShelves.size());
			
			String a = randomShelves.remove(indexA);
			randomShelves.add(a);
		}
	}
	
	//should be getDimention(int storeID)
	public int[] getDimension() {
		return dimension;
	}
	
	//should be getItscs(int storeID)
	public ArrayList<int[]> getItscs() {
		return itscs;
	}
	
	//should be getWkwys(int storeID)
	public ArrayList<int[]> getWkwys() {
		return wkwys;
	}
	
	//should be getShelves(int storeID)
	public ArrayList<int[]> getShelves() {
		return shelves;
	}
	
	//should be getStart(int storeID)
	public String getStart() {
		return "Itsc8";
	}
	
	//should be getEnd(int storeID)
	public String getEnd() {
		return "Itsc6";
	}
	
	//This would be user-entered, but for testing we need a random set of shelves
	public ArrayList<String> getTargets(int points) {
		ArrayList<String> targets = new ArrayList<String>();
		
		for (int i = 0; i < points; i++) {
			targets.add(randomShelves.get(i));
		}
		
		return targets;
	}
}
