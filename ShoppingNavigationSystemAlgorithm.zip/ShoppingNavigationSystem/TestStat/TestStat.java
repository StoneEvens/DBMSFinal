package TestStat;
import java.util.ArrayList;

//This class is a simulation of the data retrieved from database
//Will be replaced by Accessor in the future
public class TestStat {
	private ArrayList<String> storeInfo;
	private ArrayList<int[]> itscs, shelves, wkwys;
	private ArrayList<String> randomShelves;
	
	public TestStat() {
		storeInfo = new ArrayList<String>();
		storeInfo.add(String.format("%d", 7));
		storeInfo.add(String.format("%d", 7));
		storeInfo.add("Itsc8");
		storeInfo.add("Itsc6");
		
		itscs = new ArrayList<int[]>();
		shelves = new ArrayList<int[]>();
		wkwys = new ArrayList<int[]>();
		
		for (int i = 0; i < Integer.parseInt(storeInfo.get(0)); i++) {
			for (int j = 0; j < Integer.parseInt(storeInfo.get(1)); j++) {
				if (i%3 == 0 || j%3 == 0) {
					if (i%3 == 0 && j%3 == 0) {
						itscs.add(new int[] {i, j});
					} else {
						wkwys.add(new int[] {i, j});
					}
				} else {
					if (i%3 == 1) {
						shelves.add(new int[] {i, j, -1, 0});
					}
					
					if (i%3 == 2) {
						shelves.add(new int[] {i, j, 1, 0});
					}
				}
			}
		}
		
		randomShelves = new ArrayList<String>();
		
		for (int i = 0; i < shelves.size(); i++) {
			randomShelves.add(String.format("S%d", i));
		}
		
		for (int i = 0; i < 100; i++) {
			int indexA = (int)Math.floor(Math.random()*randomShelves.size());
			
			String a = randomShelves.remove(indexA);
			randomShelves.add(a);
		}
	}
	
	//should be getDimention(int storeID)
	public ArrayList<String> getStoreInfo() {
		return storeInfo;
	}
	
	//should be getItscs(int storeID)
	public ArrayList<int[]> getItscs() {
		return itscs;
	}
	
	//should be getWkwys(int storeID)
	public ArrayList<int[]> getWkwys() {
		return wkwys;
	}
	
	//should be getShelves(int storeID)
	public ArrayList<int[]> getShelves() {
		return shelves;
	}
	
	//This would be user-entered, but for testing we need a random set of shelves
	public ArrayList<String> getTargets(int points) {
		ArrayList<String> targets = new ArrayList<String>();
		
		for (int i = 0; i < points; i++) {
			targets.add(randomShelves.get(i));
		}
		
		return targets;
	}
	
	/*
	public ArrayList<String> getTargetShelves(ArrayList<String> targetProducts) {
		ArrayList<String> targetShelves = new ArrayList<String>();
		
		for (String s: targetProducts) {
			String shelf = "";
			//Find which shelf the product is one in sql and make shelf it
			//targetShelves.add(shelf);
		}
		
		return targetShelves;
	*/
}
