package mapanddistances;
import java.util.ArrayList;

import TestStat.TestStat;

//All of these would be done in the Server class later
public class Main {

	public static void main(String[] args) {
		TestStat ts = new TestStat();
		
		//Might need to login
		
		Map map = new Map(ts);
		
		for (MapElement[] li: map.getMapElements()) {
			for (MapElement obj: li) {
				System.out.print(obj.getName() + " ");
			}
			
			System.out.println();
		}
		
		System.out.println();
		
		for (Aisle a: map.getAisles()) {
			System.out.printf("%d,%d => %d,%d -> %d,%d\n",a.getAisleRow(), a.getAisleCol(), a.getItsc1().getRow(), a.getItsc1().getCol(), a.getItsc2().getRow(), a.getItsc2().getCol());
		}
		
		System.out.println();
		
		for (MapElement[] li: map.getMapElements()) {
			for (MapElement obj: li) {
				if (obj instanceof Walkway) {
					System.out.print(((Walkway)obj).getAisle().getAisleRow() + "," + ((Walkway)obj).getAisle().getAisleCol() + " ");
				} else {
					System.out.print(obj.getName() + " ");
				}
			}
			
			System.out.println();
		}
		
		System.out.println();
		
		Shelf s = (Shelf) map.getMapElement("S12");
		System.out.println(s.getWkwy().getRow() + "," + s.getWkwy().getCol());
		
		System.out.println();
		
		ArrayList<Shelf> shelfArray = new ArrayList<Shelf>();
		//Shelf s1 = map.getShelf("S15");
		//Shelf s2 = map.getShelf("S3");
		//Shelf s3 = map.getShelf("S8");
		//Shelf s4 = map.getShelf("S4");
		
		//shelfArray.add(s1);
		//shelfArray.add(s2);
		//shelfArray.add(s3);
		//shelfArray.add(s4);
		
		for (int i = 0; i < ts.getShelves().size(); i++) {
			Shelf shelf = (Shelf) map.getMapElement(String.format("S%d", i));
			shelfArray.add(shelf);
		}
		
		DistanceAlgorithm DA = new DistanceAlgorithm(map, shelfArray, (Intersection) map.getMapElement(ts.getStart()), (Intersection) map.getMapElement(ts.getEnd()));
		DA.calculateDistances();
		
		for (ArrayList<Integer> li: DA.getDistances()) {
			System.out.println(li);
		}
		
		System.out.println();
		
		System.out.println(ts.getTargets(10));
	}

}
