package mapanddistances;
import java.util.ArrayList;

import TestStat.TestStat;

public class Map {
	ArrayList<Aisle> aisles;
	MapElement[][] mapElements;
	
	//Get data from SQL (Using TestStat class for test)
	TestStat ts;
	
	public Map(TestStat ts) {
		aisles = new ArrayList<Aisle>();
		this.ts = ts;
		
		getData();
	}
	
	private void getData() {
		//Instantiate mapElements
		mapElements = new MapElement[ts.getDimension()[0]][ts.getDimension()[1]];
		
		//Always Create Intersection First
		int cnt = 0;
		for (int[] c: ts.getItscs()) {
			Intersection i = new Intersection("Itsc" + cnt, c[0], c[1]);
			
			//itscs.add(i);
			mapElements[c[0]][c[1]] = i;
			cnt++;
		}
		
		//Create Walkways
		for (int[] c: ts.getWkwys()) {
			Walkway w = new Walkway("Wkwy ", c[0], c[1], new Aisle());
			
			mapElements[c[0]][c[1]] = w;
		}
		
		//Create Shelves
		int k = 0;
		
		for (int[] c: ts.getShelves()) {
			int[] wkwyLocation = new int[] {c[2], c[3]};
			Walkway w = (Walkway) mapElements[c[0] + wkwyLocation[0]][c[1] + wkwyLocation[1]];
			Shelf s = new Shelf("S" + k, c[0], c[1], w, wkwyLocation);
			
			mapElements[c[0]][c[1]] = s;
			
			k++;
		}
		
		//Create Aisle
		//Try handle vertical aisles
		int r = 0;
		int c = -1;
		
		for (MapElement[] li: mapElements) {
			c = -1;
			int indexA = -1;
			int indexB = -1;
			
			for (int i = 0; i < li.length; i++) {
				if (li[i] instanceof Intersection) {
					indexA = indexB;
					indexB = i;
					
					if (indexA != -1) {
						c++;
						
						Aisle a = new Aisle(r, c, (Intersection)li[indexA], (Intersection)li[indexB]);
						aisles.add(a);
						
						for (int j = indexA + 1; j < indexB; j++) {
							if (li[j] instanceof Walkway) {
								((Walkway) li[j]).setAisle(a);
							}
						}
					}
				}
			}
			
			if (c != -1) {
				r++;
			}
		}
		
		//Create Distance Multiplier
		for (MapElement[] li: mapElements) {
			for (MapElement mE: li) {
				if (mE instanceof Walkway) {
					if (((Walkway) mE).getAisle().getAisleRow() >= 0) {
						mE.setDistanceMultiplier(new int[] {1, 2});
					} else {
						mE.setDistanceMultiplier(new int[] {1, 1});
					}
				} else if (mE instanceof Intersection) {
					mE.setDistanceMultiplier(new int[] {1, 1});
				}
			}
		}
	}
	
	//Very Important, has all the important information in it
	//The walkways in aisle (-1,-1) is in the "imaginary" aisle that holds everything that are not in the horizontal aisles (which are vertical aisles)
	//Those that are in the imaginary aisle are the perpendicular aisles to the shelves, so they would be VerticalWkwys in the app
	//And the rest of them would be the HorizonalWkwys in the app
	//Finding the shelves where the product is saved can also be achieved by using this list
	public MapElement[][] getMapElements() {
		return mapElements;
	}
	
	//The aisles are critical to finding the shortest distance between any to product, that is the shelf that holds the product, and is the walkway where the customer would stand in and grab the item
	public ArrayList<Aisle> getAisles() {
		return aisles;
	}
	
	//Here the customer would send a list of products first, then through SQL, we would know which shelf each product is on, then we can know the name of the shelf (Or ID, could be changed)
	//If designed properly, there should be no imaginary shelves returned, but handling the exception would be just fine.
	public MapElement getMapElement(String name) {
		MapElement mapElement = new MapElement();
		
		for (MapElement[] mE: mapElements) {
			for (MapElement e: mE) {
				if (e.getName().equals(name)) {
					mapElement = e; 
				}
			}
		}
		
		return mapElement;
	}
}
