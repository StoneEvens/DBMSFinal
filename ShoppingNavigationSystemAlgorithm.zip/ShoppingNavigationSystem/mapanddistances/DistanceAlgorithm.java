package mapanddistances;
import java.util.ArrayList;

public class DistanceAlgorithm {
	private final Map map;
	private final int LENGTH;
	private ArrayList<Shelf> shelves;
	private ArrayList<ArrayList<Integer>> distances;
	private Intersection start, end;
	
	public DistanceAlgorithm(Map map, ArrayList<Shelf> shelves, Intersection start, Intersection end) {
		this.map = map;
		this.LENGTH = shelves.size();
		this.shelves = shelves;
		this.start = start;
		this.end = end;
		
		distances = new ArrayList<ArrayList<Integer>>();
	}
	
	public void calculateDistances() {
		for (int i = 0; i < LENGTH + 1; i++) {
			ArrayList<Integer> dpr = new ArrayList<Integer>();
			
			if (i < LENGTH - 1) {
				for (int j = i + 1; j < LENGTH; j++) {
					//Check the shortest distance between any two products searched
					dpr.add(computeDistance(shelves.get(i), shelves.get(j)));
				}
			} else if (i < LENGTH) {
				for (int j = 0; j < LENGTH; j++) {
					dpr.add(computeDistance(start, shelves.get(j)));
				}
			} else {
				for (int j = 0; j < LENGTH; j++) {
					dpr.add(computeDistance(end, shelves.get(j)));
				}
			}
			
			distances.add(dpr);
		}
	}
	
	//If calculating distance between entrance and shelves or exit and shelves, place non-shelf object in the first parameter
	private int computeDistance(MapElement start, MapElement end) {
		//Instantiate 4 intersections (two for each aisle, where the two products are placed on)
		MapElement startElement = start;
		MapElement endElement = end;
		int shortestD = 1000;
		
		if (startElement instanceof Shelf && endElement instanceof Shelf) {
			Intersection startItsc1 = ((Shelf) startElement).getWkwy().getAisle().getItsc1();
			Intersection startItsc2 = ((Shelf) startElement).getWkwy().getAisle().getItsc2();
			Intersection endItsc1 = ((Shelf) endElement).getWkwy().getAisle().getItsc1();
			Intersection endItsc2 = ((Shelf) endElement).getWkwy().getAisle().getItsc2();
			
			ArrayList<Intersection> startItscs = new ArrayList<Intersection>();
			ArrayList<Intersection> endItscs = new ArrayList<Intersection>();
			startItscs.add(startItsc1);
			startItscs.add(startItsc2);
			endItscs.add(endItsc1);
			endItscs.add(endItsc2);
			
			//Find which combination is the shortest
			int[] d = new int[4];
			int[][] dir = new int[4][2];
			
			for (Intersection s: startItscs) {
				for (Intersection e: endItscs) {
					dir[startItscs.indexOf(s)*2 + endItscs.indexOf(e)] = new int[] {s.getRow() - e.getRow(), s.getCol() - e.getCol()};
					
					//System.out.println(dir[startItscs.indexOf(s)*2 + endItscs.indexOf(e)][1]);
					
					convertDirToD(startItscs.indexOf(s)*2 + endItscs.indexOf(e), dir, d, s);
				}
			}
			
			if (!((Shelf) startElement).getWkwy().getAisle().equals(((Shelf) endElement).getWkwy().getAisle())) {
				for (Intersection s: startItscs) {
					for (Intersection e: endItscs) {
						//dir[startItscs.indexOf(s)*2 + endItscs.indexOf(e)][0] += (s.getRow() - startElement.getWkwy().getRow() + e.getRow() - endElement.getWkwy().getRow());
						//dir[startItscs.indexOf(s)*2 + endItscs.indexOf(e)][1] += (s.getCol() - startElement.getWkwy().getCol() + e.getCol() - endElement.getWkwy().getCol());
						
						dir[startItscs.indexOf(s)*2 + endItscs.indexOf(e)][0] = (((Shelf) startElement).getWkwy().getRow() - s.getRow());
						dir[startItscs.indexOf(s)*2 + endItscs.indexOf(e)][1] = (((Shelf) startElement).getWkwy().getCol() - s.getCol());
						
						convertDirToD(startItscs.indexOf(s)*2 + endItscs.indexOf(e), dir, d, ((Shelf) startElement).getWkwy());
						
						dir[startItscs.indexOf(s)*2 + endItscs.indexOf(e)][0] = (((Shelf) endElement).getWkwy().getRow() - e.getRow());
						dir[startItscs.indexOf(s)*2 + endItscs.indexOf(e)][1] = (((Shelf) endElement).getWkwy().getCol() - e.getCol());
						
						convertDirToD(startItscs.indexOf(s)*2 + endItscs.indexOf(e), dir, d, ((Shelf) endElement).getWkwy());
						
						d[startItscs.indexOf(s)*2 + endItscs.indexOf(e)] += 1;
					}
				}
			} else {
				for (Intersection s: startItscs) {
					for (Intersection e: endItscs) {
						dir[startItscs.indexOf(s)*2 + endItscs.indexOf(e)][0] = (((Shelf) startElement).getWkwy().getRow() - ((Shelf) endElement).getWkwy().getRow());
						dir[startItscs.indexOf(s)*2 + endItscs.indexOf(e)][1] = (((Shelf) startElement).getWkwy().getCol() - ((Shelf) endElement).getWkwy().getCol());
						
						convertDirToD(startItscs.indexOf(s)*2 + endItscs.indexOf(e), dir, d, ((Shelf) startElement).getWkwy());
					}
				}
			}
			
			for (int l: d) {
				if (l < shortestD) {
					shortestD = l;
				}
			}
		} else {
			Intersection startItsc = (Intersection) startElement;
			Intersection endItsc1 = ((Shelf) endElement).getWkwy().getAisle().getItsc1();
			Intersection endItsc2 = ((Shelf) endElement).getWkwy().getAisle().getItsc2();
			
			ArrayList<Intersection> endItscs = new ArrayList<Intersection>();
			endItscs.add(endItsc1);
			endItscs.add(endItsc2);
			
			int d[] = new int[2];
			int[][] dir = new int[2][2];
			
			for (Intersection e: endItscs) {
				dir[endItscs.indexOf(e)] = new int[] {startItsc.getRow() - e.getRow(), startItsc.getCol() - e.getCol()};
				
				//System.out.println(startItsc.getRow() + "," + startItsc.getCol());
				//System.out.println(e.getRow() + "," + e.getRow());
				//System.out.println((startItsc.getRow() - e.getRow()) + "," + (startItsc.getCol() - e.getCol()));
				//System.out.println(e.getName());
				
				
				convertDirToD(endItscs.indexOf(e), dir, d, startItsc);
			}
			
			if (!(((Intersection) startItsc).equals(((Shelf) endElement).getWkwy().getAisle().getItsc1()) || ((Intersection) startItsc).equals(((Shelf) endElement).getWkwy().getAisle().getItsc2()))) {
				for (Intersection e: endItscs) {
					dir[endItscs.indexOf(e)][0] = (((Shelf) endElement).getWkwy().getRow() - e.getRow());
					dir[endItscs.indexOf(e)][1] = (((Shelf) endElement).getWkwy().getCol() - e.getCol());
					
					convertDirToD(endItscs.indexOf(e), dir, d, ((Shelf) endElement).getWkwy());
					
					d[endItscs.indexOf(e)] += 1;
				}
			} else {
				for (Intersection e: endItscs) {
					dir[endItscs.indexOf(e)][0] = (startElement.getRow() - ((Shelf) endElement).getWkwy().getRow());
					dir[endItscs.indexOf(e)][1] = (startElement.getCol() - ((Shelf) endElement).getWkwy().getCol());
					
					convertDirToD(endItscs.indexOf(e), dir, d, startElement);
				}
			}
			
			/*
			d[0] = Math.abs(startItsc.getRow() - endItsc1.getRow()) + Math.abs(startItsc.getCol() - endItsc1.getCol()) - 1;
			d[1] = Math.abs(startItsc.getRow() - endItsc2.getRow()) + Math.abs(startItsc.getCol() - endItsc2.getCol()) - 1;
			
			if (!(((Intersection) startItsc).equals(((Shelf) endElement).getWkwy().getAisle().getItsc1()) || ((Intersection) startItsc).equals(((Shelf) endElement).getWkwy().getAisle().getItsc2()))) {
				d[0] += Math.abs(endItsc1.getRow() - endElement.getRow()) + Math.abs(endItsc1.getCol() - endElement.getCol());
				d[1] += Math.abs(endItsc2.getRow() - endElement.getRow()) + Math.abs(endItsc2.getCol() - endElement.getCol());
			} else {
				d[0] += Math.abs(startItsc.getRow() - endElement.getRow()) + Math.abs(startItsc.getCol() - endElement.getCol());
				d[1] += Math.abs(startItsc.getRow() - endElement.getRow()) + Math.abs(startItsc.getCol() - endElement.getCol());
			}
			*/
			if (d[0] <= d[1]) {
				shortestD = d[0];
			} else {
				shortestD = d[1];
			}
		}
		
		return shortestD;
	}
	
	private void convertDirToD(int i, int[][] dir, int[] d, MapElement s) {
		if (dir[i][0] != 0) {
			int[] curPos = new int[] {s.getRow(), s.getCol()};
			
			while (dir[i][0] < 0) {
				dir[i][0]++;
				curPos[0]++;
				
				d[i] += map.getMapElements()[curPos[0]][curPos[1]].getDistanceMultiplier()[0];
			}
			
			while (dir[i][0] > 0) {
				//System.out.println(dir[i][0] + "," + dir[i][1]);
				//System.out.println(curPos[0]);
				dir[i][0]--;
				curPos[0]--;
				
				//System.out.println(dir[i][0] + "," + dir[i][1]);
				//System.out.println(curPos[0]);
				//System.out.println("-------------------------");
				
				MapElement[] li = map.getMapElements()[curPos[0]];
				MapElement mE = li[curPos[1]];
				
				d[i] += mE.getDistanceMultiplier()[0];
			}
		}
		
		if (dir[i][1] != 0) {
			int[] curPos = new int[] {s.getRow(), s.getCol()};
			
			while (dir[i][1] < 0) {
				dir[i][1]++;
				curPos[1]++;
				
				d[i] += map.getMapElements()[curPos[0]][curPos[1]].getDistanceMultiplier()[1];
			}
			
			while (dir[i][1] > 0) {
				dir[i][1]--;
				curPos[1]--;
				
				d[i] += map.getMapElements()[curPos[0]][curPos[1]].getDistanceMultiplier()[1];
			}
		}
	}
	
	//Very important because the shortest path among all points would need these distances to calculate
	public ArrayList<ArrayList<Integer>> getDistances() {
		return distances;
	}
	
	public int findElement(MapElement element) {
		for (Shelf s: shelves) {
			if (element.getName().equals(s.getName())) {
				return shelves.indexOf(s);
			}
		}
		
		if (element.getName().equals(start.getName())) {
			return LENGTH - 1;
		}
		
		if (element.getName().equals(end.getName())) {
			return LENGTH;
		}
		
		return -10;
	}
	
	public int getLength() {
		return LENGTH;
	}
	
	public int calculateDistance(int indexA, int indexB) {
		if (indexA >= LENGTH - 1) {
			return distances.get(indexA).get(indexB);
		} else if (indexB >= LENGTH - 1) {
			return distances.get(indexB).get(indexA);
		} else {
			return distances.get(Math.min(indexA, indexB)).get(Math.max(indexA, indexB) - Math.min(indexA, indexB) - 1);
		}
	}
}
