package tsp;

public class Vertice {
	private String name;
	private double row, column;
	
	public Vertice(String name, double row, double column) {
		this.name = name;
		this.row = row;
		this.column = column;
	}
	
	public String getName() {
		return name;
	}
	
	public double getRow() {
		return row;
	}
	
	public double getColumn() {
		return column;
	}
}
