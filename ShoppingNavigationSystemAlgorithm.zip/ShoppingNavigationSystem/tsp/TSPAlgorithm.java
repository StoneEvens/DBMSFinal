package tsp;

import java.util.ArrayList;

import mapanddistances.DistanceAlgorithm;
import mapanddistances.Intersection;
import mapanddistances.Shelf;

public class TSPAlgorithm {
	private volatile ArrayList<Integer> bestOrderEver;
	private volatile int shortestDEver;
	@SuppressWarnings("unused")
	private volatile int generations;
	private volatile int turns;
	private final int POINTS;
	private final Intersection start, end;
	private final DistanceAlgorithm DA;
	private ArrayList<Shelf> targets;
	
	public TSPAlgorithm(ArrayList<Shelf> shelves, ArrayList<Shelf> targets, Intersection start, Intersection end, DistanceAlgorithm DA) {
		this.POINTS = targets.size();
		this.targets = targets;
		this.start = start;
		this.end = end;
		this.DA = DA;
		DA.calculateDistances();
		bestOrderEver = new ArrayList<Integer>();
		shortestDEver = 1000;
		generations = 0;
		turns = 0;
	}
	
	public void start() {
		AverageDistanceAlgorithm ada = new AverageDistanceAlgorithm(targets, start, end, DA);
		bestOrderEver = ada.getOrder();
		
		//We are only running genetic algorithm one time to save time, you can always do more times for maximum accuracy
		//Note: More accuracy means more computing time
		//For the next line just change the second argument to i < # where # is the amount of times you would like it to try
		for (int i = 0; i < POINTS / 2; i++) {
			turns = 0;
			
			//If you wish to increase rounds, please do it beforehand
			for (int j = 0; j < POINTS; j++) {
				Thread thread = new Thread(new Runnable() {
						@Override
					public void run() {
						// TODO Auto-generated method stub
						GeneticAlgorithm ga = new GeneticAlgorithm(targets, start, end, bestOrderEver, DA);					
						ga.start();
						
						if (ga.getShortestD() < shortestDEver) {
							shortestDEver = ga.getShortestD();
							bestOrderEver = ga.getBestOrder();
						}
						
						generations += ga.getGeneration();
						
						turns++;
					}
					
				});
				
				thread.start();
			}
			
			while (turns < POINTS) {
				//Try handle failed operation
			}
		}
	}
	
	public ArrayList<Integer> getBestOrderEver() {
		return bestOrderEver;
	}
	
	public int getShortestDEver() {
		return shortestDEver;
	}
}
