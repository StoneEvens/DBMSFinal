package tsp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import mapanddistances.DistanceAlgorithm;
import mapanddistances.MapElement;
import mapanddistances.Shelf;

public class AverageDistanceAlgorithm {
	private final DistanceAlgorithm DA;
	private ArrayList<Shelf> targets;
	private ArrayList<Integer> order;
	private MapElement start, end;
	public int shortestD = 1000;
	
	public ArrayList<int[]> distances;
	
	public AverageDistanceAlgorithm(ArrayList<Shelf> targets, MapElement start, MapElement end, DistanceAlgorithm da) {
		this.DA = da;
		this.targets = targets;
		this.start = start;
		this.end = end;
		distances = new ArrayList<int[]>();
		order = new ArrayList<Integer>();
		
		if (!targets.isEmpty()) {
			calculateAverageDistance();
			Collections.sort(distances, Comparator.comparingDouble(a -> a[1]));
			/*
			for (double[] da: distances) {
				for (double d: da) {
					System.out.print(d + ", ");
				}
				
				System.out.println();
			}
			*/
			computeOrder();
			
			//System.out.println(order);
			//calculateTotalDistance();
		}
	}
	
	private void calculateAverageDistance() {
		for (Shelf v: targets) {
			int startIndex = DA.findElement(start);
			int endIndex = DA.findElement(end);
			int indexA = DA.findElement(v);
			
			int d1 = DA.calculateDistance(startIndex, indexA);
			int d2 = DA.calculateDistance(endIndex, indexA);
			
			if (startIndex >= DA.getLength() - 1) {
				d1 = DA.getDistances().get(startIndex).get(indexA);
			} else {
				d1 = DA.getDistances().get(Math.min(startIndex, indexA)).get(Math.max(startIndex, indexA));
			}
			
			if (endIndex >= DA.getLength() - 1) {
				d2 = DA.getDistances().get(endIndex).get(indexA);
			} else {
				d2 = DA.getDistances().get(Math.min(endIndex, indexA)).get(Math.max(endIndex, indexA));
			}
			
			int[] ds = new int[4];
			ds[0] = targets.indexOf(v);
			ds[1] = (d1 * d2);
			ds[2] = d1;
			ds[3] = d2;
			
			distances.add(ds);
			
			//System.out.println(d1 + ", " + d2 + ", " + (d1 + d2));
		}
	}
	
	private void computeOrder() {
		ArrayList<Shelf> leftList = new ArrayList<Shelf>();
		ArrayList<Integer> leftOrder = new ArrayList<Integer>();
		ArrayList<Shelf> rightList = new ArrayList<Shelf>();
		ArrayList<Integer> rightOrder = new ArrayList<Integer>();
		
		for (int i = 0; i < distances.size() - 1; i++) {
			if (distances.get(i)[2] < distances.get(i)[3]) {
				leftList.add(targets.get((int)distances.get(i)[0]));
				leftOrder.add((int)distances.get(i)[0]);
			} else {
				rightList.add(targets.get((int)distances.get(i)[0]));
				rightOrder.add((int)distances.get(i)[0]);
			}
		}
		
		MapElement furthest = targets.get((int)distances.get(distances.size() - 1)[0]);
		
		if (leftList.size() > 10) {
			AverageDistanceAlgorithm adal = new AverageDistanceAlgorithm(leftList, start, furthest, DA);
			leftOrder = adal.getOrder();
		} else {
			BruteForceAlgorithm bfal = new BruteForceAlgorithm(leftList, start, furthest, DA);
			leftOrder = bfal.start();
		}
		
		if (rightList.size() > 10) {
			AverageDistanceAlgorithm adar = new AverageDistanceAlgorithm(rightList, furthest, end, DA);
			rightOrder = adar.getOrder();
		} else {
			BruteForceAlgorithm bfar = new BruteForceAlgorithm(rightList, furthest, end, DA);
			rightOrder = bfar.start();
		}
		
		for (int i: leftOrder) {
			order.add(targets.indexOf(leftList.get(i)));
		}
		
		order.add(targets.indexOf(furthest));
		
		for (int j: rightOrder) {
			order.add(targets.indexOf(rightList.get(j)));
		}
	}
	
	public ArrayList<Integer> getOrder() {
		return order;
	}
	
	/*
	public void calculateTotalDistance() {
		double d = Math.round(Math.hypot(start.getRow() - targets.get(order.get(0)).getRow(), start.getCol() - targets.get(order.get(0)).getCol()));
		
		for (int i = 0; i < order.size() - 1; i++) {
			int k = order.get(i);
			int l = order.get(i + 1);
			d += Math.round(Math.hypot(targets.get(k).getRow() - targets.get(l).getRow(), targets.get(k).getCol() - targets.get(l).getCol()));
		}
		
		d += Math.round(Math.hypot(end.getRow() - targets.get(order.get(order.size() - 1)).getRow(), end.getCol() - targets.get(order.get(order.size() - 1)).getCol()));
		
		shortestD = d;
		//System.out.println("Total Distance: " + d);
	}
	*/
}
