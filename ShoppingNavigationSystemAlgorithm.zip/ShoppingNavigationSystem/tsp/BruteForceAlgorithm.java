package tsp;
import java.util.ArrayList;
import java.util.Collections;
import mapanddistances.DistanceAlgorithm;
import mapanddistances.MapElement;
import mapanddistances.Shelf;

public class BruteForceAlgorithm {
	private final DistanceAlgorithm DA;
	private ArrayList<Shelf> targets;
	private ArrayList<Integer> order;
	private MapElement start, end;
	private int count;
	private ArrayList<Integer> bestOrder;
	private int shortestD = 1000;
	
	public BruteForceAlgorithm(ArrayList<Shelf> targets, MapElement start, MapElement end, DistanceAlgorithm DA) {
		this.DA = DA;
		this.targets = targets;
		order = new ArrayList<Integer>();
		bestOrder = new ArrayList<Integer>();
		this.count = 0;
		
		this.start = start;
		this.end = end;
		
		for (int i = 0; i < targets.size(); i++) {
			order.add(i);
		}
		
		if (!targets.isEmpty()) {
			//distances = new ArrayList<ArrayList<Double>>();
			//getDistances(targets.size());
			/*
			for (ArrayList<Double> list: distances) {
				for (double d: list) {
					System.out.print(d + " ");
				}
				
				System.out.println();
			}
			*/
		}
	}
	
	protected void getDistances(int count) {
		for (int i = 0; i < count + 2; i++) {
			ArrayList<Double> temp = new ArrayList<Double>();
			
			if (i < count) {
				for (int j = i + 1; j < count; j++) {
					temp.add((double) Math.round(Math.hypot(targets.get(i).getWkwy().getRow() - targets.get(j).getRow(), targets.get(i).getWkwy().getCol() - targets.get(j).getWkwy().getCol())));
				}
			} else {
				if (i == count) {
					for (int j = 0; j < count; j++) {
						temp.add((double) Math.round(Math.hypot(start.getRow() - targets.get(j).getWkwy().getRow(), start.getCol() - targets.get(j).getWkwy().getCol())));
					}
				} else {
					for (int j = 0; j < count; j++) {
						temp.add((double) Math.round(Math.hypot(end.getRow() - targets.get(j).getWkwy().getRow(), end.getCol() - targets.get(j).getWkwy().getCol())));
					}
				}
			}
		}
	}
	
	public ArrayList<Integer> start() {
		if (targets.isEmpty()) {
			return order;
		} else {
			while (true) {
				count++;
				
				calculateDistance();
				
				if (!nextOrder()) {
					return bestOrder;
				}
			}
		}
	}
	
	private void calculateDistance() {
		int startIndex = DA.getLength() - 1;
		int endIndex = DA.findElement(targets.get(order.get(0)));
		//System.out.println(start.getName() + startIndex);
		//System.out.println(endIndex);
		
		int d = DA.calculateDistance(startIndex, endIndex);
		
		for (int i = 1; i < order.size(); i++) {
			startIndex = endIndex;
			endIndex = DA.findElement(targets.get(order.get(i)));
			
			d += DA.calculateDistance(startIndex, endIndex);
		}
		
		startIndex = DA.getLength();
		endIndex = DA.findElement(targets.get(order.get(order.size() - 1)));
		//System.out.println(startIndex);
		//System.out.println(end.getName() + endIndex);
		
		d += DA.calculateDistance(startIndex, endIndex);
		
		
		if (d <= shortestD) {
			bestOrder.clear();
			bestOrder.addAll(order);
			shortestD = d;
		}
	}
	
	public boolean nextOrder() {
		int largestI = -1;
		int largestJ = -1;
		
		//Largest I
		for (int i = 0; i < order.size() - 1; i++) {
			if (order.get(i) < order.get(i + 1)) {
				largestI = i;
			}
		}
		
		if (largestI == -1) {
			return false;
		}
		
		//Largest J
		for (int j = 0; j < order.size(); j++) {
			if (order.get(largestI) < order.get(j)) {
				largestJ = j;
			}
		}
		
		//Swap
		int temp = order.get(largestI);
		order.set(largestI, order.get(largestJ));
		order.set(largestJ, temp);
		
		ArrayList<Integer> tempList = new ArrayList<Integer>(order.subList(largestI + 1, order.size() - 1));
		Collections.reverse(tempList);
		
		order.removeAll(order.subList(largestI + 1, order.size() - 1));
		order.addAll(tempList);
		
		return true;
	}
	
	public int getCount() {
		return count;
	}
	
	//For Debug Only
	public ArrayList<Shelf> getTargets() {
		return targets;
	}
	
	public MapElement getStart() {
		return start;
	}
	
	public MapElement getEnd() {
		return end;
	}
	
	public ArrayList<Integer> getBestOrder() {
		return bestOrder;
	}
	
	public int getshortestD() {
		return shortestD;
	}
}
