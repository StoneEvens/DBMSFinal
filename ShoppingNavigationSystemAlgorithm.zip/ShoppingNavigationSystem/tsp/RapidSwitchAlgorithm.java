package tsp;
import java.util.ArrayList;
import java.util.Collections;

import mapanddistances.DistanceAlgorithm;
import mapanddistances.Intersection;
import mapanddistances.Shelf;

public class RapidSwitchAlgorithm {
	private final DistanceAlgorithm DA;
	private ArrayList<Shelf> targets;
	private ArrayList<Integer> order, bestOrder;
	private Intersection start, end;
	private int shortestD = 1000;
	
	public RapidSwitchAlgorithm(ArrayList<Shelf> targets, Intersection start, Intersection end, ArrayList<Integer> order, DistanceAlgorithm DA) {
		this.DA = DA;
		this.targets = targets;
		this.start = start;
		this.end = end;
		this.order = order;
		this.bestOrder = order;
		
		shortestD = calculateDistance(this.order, this.start, this.end);
	}
	
	public void start() {
		for (int i = 0; i < order.size(); i++) {
			for (int j = i; j < order.size(); j++) {
				ArrayList<Integer> tempOrder = new ArrayList<Integer>(order);
				ArrayList<Integer> tempList = new ArrayList<Integer>(tempOrder.subList(i, j + 1));
				tempOrder.removeAll(tempList);
				Collections.reverse(tempList);
				tempOrder.addAll(i, tempList);
				
				int d1 = calculateDistance(tempOrder, start, end);
				int d2 = calculateDistance(tempOrder, end, start);
				
				if (d1 <= shortestD || d2 <= shortestD) {
					if (d1 < d2) {
						shortestD = d1;
						bestOrder = tempOrder;
					} else {
						Collections.reverse(tempOrder);
						
						shortestD = d2;
						bestOrder = tempOrder;
					}
				}
			}
		}
	}
	
	protected int calculateDistance(ArrayList<Integer> order, Intersection start, Intersection end) {
		int startIndex = DA.getLength() - 1;
		int endIndex = DA.findElement(targets.get(order.get(0)));
		
		int d = DA.calculateDistance(startIndex, endIndex);
		
		for (int i = 1; i < order.size(); i++) {
			startIndex = endIndex;
			endIndex = DA.findElement(targets.get(order.get(i)));
			
			d += DA.calculateDistance(startIndex, endIndex);
		}
		
		startIndex = DA.getLength();
		endIndex = DA.findElement(targets.get(order.get(order.size() - 1)));
		
		d += DA.calculateDistance(startIndex, endIndex);
		
		return d;
	}
	
	public ArrayList<Integer> getBestOrder() {
		return bestOrder;
	}
	
	public int getShortestD() {
		return shortestD;
	}
}
