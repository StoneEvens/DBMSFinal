package tsp;
import java.util.ArrayList;

import TestStat.TestStat;
import mapanddistances.DistanceAlgorithm;
import mapanddistances.Intersection;
import mapanddistances.Map;
import mapanddistances.Shelf;

public class TSPTest {
	//You can customize the amount of points going through
	//Note: Having 12 or more will make your computer run it for a long time
	//If you wish to test it, you can comment out the line found later
	final int POINTS = 10;
	@SuppressWarnings("unused")
	private final int ROUNDS;
	private int bruteDistance = 1000;
	private int status = 0;
	public BruteForceAlgorithm bfa;
	public Map map;
	public TSPAlgorithm tspa;
	public TestStat ts;
	
	public TSPTest() {
		//Change Here
		//If you wish to have more accurate results, you can set rounds to vertexes
		//ROUNDS = 1;
		//Make sure to comment this if you wish to increase rounds
		ts = new TestStat();
		ROUNDS = POINTS;
		map = new Map(ts);
		
		//System.out.println(ts.getTargets(POINTS));
		
		ArrayList<Shelf> shelves = new ArrayList<Shelf>();
		for (int i = 0; i < ts.getShelves().size(); i++) {
			Shelf shelf = (Shelf) map.getMapElement(String.format("S%d", i));
			shelves.add(shelf);
		}
		
		Intersection start = map.getStart();
		Intersection end = map.getEnd();
		
		ArrayList<Shelf> targets = new ArrayList<Shelf>();
		for (String s: ts.getTargets(POINTS)) {
			Shelf shelf = (Shelf) map.getMapElement(s);
			
			//System.out.println(shelf.getName());
			
			targets.add(shelf);
		}
		
		DistanceAlgorithm DA = new DistanceAlgorithm(map, shelves, start, end);
		DA.calculateDistances();
		
		//for (ArrayList<Integer> li: DA.getDistances()) {
			//System.out.println(li);
		//}
		
		bfa = new BruteForceAlgorithm(targets, start, end, DA);
		
		long startTime = System.currentTimeMillis();
		
		//If you wish to test more than 13 points, I suggest you comment out the following line
		//Note: you will only be able to see that it ran successfully because there is nothing to be compared to
		//The exact shortest distance takes way to long to calculate
		bfa.start();
		///If you wish to see the result, you can uncomment the following
		
		//System.out.println(String.format("Absolute Best Order: %s", bfa.getBestOrder()));
		//System.out.println(String.format("Shortest Distance: %d", bfa.getshortestD()));
		//System.out.println(String.format("Tried %d Orders", bfa.getCount()));
		
		
		bruteDistance = bfa.getshortestD();
		
		long endTime = System.currentTimeMillis();
		
		//Uncomment it to see the runtime
		System.out.println(String.format("Time Used: %s seconds", (endTime - startTime) / 1000d).toString());
		
		tspa = new TSPAlgorithm(shelves, targets, start, end, DA);
		tspa.start();
		
		//Again, if you wish to see the result, you can uncomment the following
		
		//System.out.println(String.format("Relative Best Order: %s", tspa.getBestOrderEver().toString()));
		//System.out.println(String.format("Relative Distance: %d", tspa.getShortestDEver()));
		//System.out.println(String.format("Tried %d Generations", generations));
		
		
		startTime = endTime;
		endTime = System.currentTimeMillis();
		
		
		//System.out.println(String.format("Absolute Best Order: %s", bfa.getBestOrder()));
		//System.out.println(String.format("Relative Best Order: %s", bestOrderEver.toString()));
		
		//Uncomment it to see the runtime
		System.out.println(String.format("Time Used: %s seconds", (endTime - startTime) / 1000d).toString());
		
		if (bruteDistance == tspa.getShortestDEver()) {
			System.out.println("Perfect!");
			status = 1;
		} else if (tspa.getShortestDEver() - bruteDistance < 0) {
			System.out.println("WTF???");
			status = -1;
		} else if (tspa.getShortestDEver() - bruteDistance < 2) {
			System.out.println("Great!");
			status = 2;
		} else if (tspa.getShortestDEver() - bruteDistance < 4) {
			System.out.println("Okay");
			status = 3;
		} else {
			System.out.println("F NO! " + (tspa.getShortestDEver() - bruteDistance));
			status = 4;
		}
	}
	
	public int getStatus() {
		return status;
	}
}
