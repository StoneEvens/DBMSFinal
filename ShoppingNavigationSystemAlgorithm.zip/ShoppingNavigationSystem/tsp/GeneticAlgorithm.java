package tsp;
import java.util.ArrayList;
import java.util.Collections;

import mapanddistances.DistanceAlgorithm;
import mapanddistances.Intersection;
import mapanddistances.Shelf;

public class GeneticAlgorithm {
	private final DistanceAlgorithm DA;
	//You may mess around with the population size, the GAP, and the mutate rate
	//Larger population size means more likely to find the absolute best solution, but at a cost of time
	//GAP means the number of generations that needs to be the same, if the best solution found is the same for 50 generations, it is likely that it is the best solution
	//Larger GAP means the program will run more times to check if anything could be done better, but at a cost of time
	//Mutate rate is the probability for two places to be swapped by their order, in my own testing 0.3 is the best
	private final int POPSIZE = 80;
	private final int GAP = 50;
	private final double MUTATERATE = 0.1;
	private ArrayList<Shelf> targets;
	private ArrayList<Integer> bestOrder;
	private Intersection start, end;
	
	private int generation;
	private int shortestD = 1000;
	private int lastModifyGen;
	private double totalDistance;
	
	private ArrayList<ArrayList<Integer>> population;
	private ArrayList<Double> scores;
	
	//Constructor
	public GeneticAlgorithm(ArrayList<Shelf> targets, Intersection start, Intersection end, ArrayList<Integer> bestOrderEver, DistanceAlgorithm DA) {
		this.DA = DA;
		this.targets = targets;
		this.start = start;
		this.end = end;
		
		generation = 0;
		lastModifyGen = 0;
		
		population = new ArrayList<ArrayList<Integer>>();
		scores = new ArrayList<Double>();
		bestOrder = new ArrayList<Integer>();
		
		//Initial Population
		for (int j = 0; j < POPSIZE; j++) {
			population.add(bestOrderEver);
		}
	}
	
	
	public ArrayList<Integer> start() {
		while (true) {
			generation++;
			calculateScores();
			normalizeScores();
			population = nextGeneration();
			
			if (generation - lastModifyGen > GAP) {
				RapidSwitchAlgorithm rsa = new RapidSwitchAlgorithm(targets, start, end, getBestOrder(), DA);
				rsa.start();
				
				shortestD = rsa.getShortestD();
				
				return rsa.getBestOrder();
			}
		}
	}
	
	
	protected void shuffle(ArrayList<Integer> list, int times) {
		for (int i = 0; i < times; i++) {
			int indexA = (int) Math.floor(Math.random()*list.size());
			int indexB = (int) Math.floor(Math.random()*list.size());
			
			int temp = list.get(indexA);
			list.set(indexA, list.get(indexB));
			list.set(indexB, temp);
		}
	}
	
	protected int calculateDistance(ArrayList<Integer> order) {
		int startIndex = DA.getLength() - 1;
		int endIndex = DA.findElement(targets.get(order.get(0)));
		
		int d = DA.calculateDistance(startIndex, endIndex);
		
		for (int i = 1; i < order.size(); i++) {
			startIndex = endIndex;
			endIndex = DA.findElement(targets.get(order.get(i)));
			
			d += DA.calculateDistance(startIndex, endIndex);
		}
		
		startIndex = DA.getLength();
		endIndex = DA.findElement(targets.get(order.get(order.size() - 1)));
		
		d += DA.calculateDistance(startIndex, endIndex);
		
		return d;
	}
	
	protected void calculateScores() {
		totalDistance = 0;
		
		for (ArrayList<Integer> list: population) {
			/*
			System.out.print(start.getName() + " ");
			for (int i: list) {
				System.out.print(targets.get(i).getName() + " ");
			}
			System.out.print(end.getName() + " \n");
			*/
			
			int score = calculateDistance(list);
			scores.add((double) score);
			totalDistance += score;
			
			if (score < getShortestD()) {
				shortestD = score;
				bestOrder = list;
				lastModifyGen = generation;
			}
		}
	}
	
	protected void normalizeScores() {
		for (double distance: scores) {
			distance = (distance /(double) totalDistance);
		}
	}
	
	protected ArrayList<ArrayList<Integer>> nextGeneration() {
		ArrayList<ArrayList<Integer>> newPopulation = new ArrayList<ArrayList<Integer>>();
		
		for (int i = 0; i < population.size(); i++) {
			ArrayList<Integer> newOrder = crossover(pickFrom(population, scores), pickFrom(population, scores));
			
			mutate(newOrder);
			
			newPopulation.add(newOrder);
		}
		
		return newPopulation;
	}
	
	protected ArrayList<Integer> pickFrom(ArrayList<ArrayList<Integer>> gList, ArrayList<Double> pList) {
		int index = 0;
		double p = Math.random();
		
		while (p > 0) {
			p = p - pList.get(index);
			index++;
		}
		
		index--;
		return gList.get(index);
	}
	
	protected ArrayList<Integer> crossover(ArrayList<Integer> order1, ArrayList<Integer> order2) {
		int startIndex = (int) Math.floor(Math.random()*order1.size());
		int endIndex = startIndex + (int) Math.floor(Math.random()*(order1.size() - startIndex));
		
		ArrayList<Integer> newOrder = new ArrayList<Integer>(order1.subList(startIndex, endIndex));
		
		for (int j: order2) {
			if (!newOrder.contains(j)) {
				newOrder.add(j);
			}
		}
		
		//System.out.println(order1 + "" + order2 + "" + newOrder);
		
		return newOrder;
	}
	
	protected void mutate(ArrayList<Integer> order) {
		for (int i = 0; i < order.size(); i++) {
			double p = Math.random();
			
			if (p < MUTATERATE) {
				int indexA = (int) Math.floor(Math.random()*order.size());
				int pos = (int) Math.floor(Math.random()*(order.size() - 1));
				int temp = order.get(indexA);
				
				order.remove(indexA);
				order.add(pos, temp);
			}
			
			if (p > (0.9)) {
				int indexA = (int) Math.floor(Math.random()*order.size());
				int length = (int) Math.floor(Math.random()*(order.size() - indexA));
				
				ArrayList<Integer> tempList = new ArrayList<Integer>(order.subList(indexA, indexA + length + 1));
				order.removeAll(tempList);
				Collections.reverse(tempList);
				order.addAll(indexA, tempList);
			}
		}
	}
	
	public int getGeneration() {
		return generation;
	}
	
	public int getShortestD() {
		return shortestD;
	}

	public ArrayList<Integer> getBestOrder() {
		return bestOrder;
	}

	public void setPopulation(ArrayList<ArrayList<Integer>> population) {
		this.population = population;
	}
}