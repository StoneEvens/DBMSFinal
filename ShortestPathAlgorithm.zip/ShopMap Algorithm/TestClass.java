import java.util.ArrayList;

public class TestClass {
	volatile ArrayList<Integer> bestOrderEver = new ArrayList<Integer>();
	volatile double shortestDEver = 1000;
	volatile int generations = 0;
	volatile int turns = 0;
	
	//You can customize the amount of points going through
	//Note: Having 13 or more will make your computer run it for a long time
	//If you wish to test it, you can comment out the line found later
	final int Vertexes = 10;
	int ROUNDS;
	boolean determinator = true;
	
	int bruteDistance = 1000;
	
	int status = 0;
	
	public BruteForceAlgorithm bfa;
	
	public TestClass() {
		//Change Here
		//If you wish to have more accurate results, you can set rounds to vertexes
		//ROUNDS = 1;
		//Make sure to comment this if you wish to increase rounds
		ROUNDS = Vertexes;
		
		bfa = new BruteForceAlgorithm(Vertexes);
		
		long start = System.currentTimeMillis();
		
		//If you wish to test more than 13 points, I suggest you comment out the following line
		//Note: you will only be able to see that it ran successfully because there is nothing to be compared to
		//The exact shortest distance takes way to long to calculate
		bfa.start();
		///If you wish to see the result, you can uncomment the following
		
		//System.out.println(String.format("Absolute Best Order: %s", bfa.getBestOrder()));
		//System.out.println(String.format("Shortest Distance: %.0f", bfa.shortestD));
		//System.out.println(String.format("Tried %d Orders", bfa.getCount()));
		
		
		bruteDistance = (int)bfa.shortestD;
		
		long end = System.currentTimeMillis();
		
		//Uncomment it to see the runtime
		System.out.println(String.format("Time Used: %s seconds", (end - start) / 1000d).toString());
		
		AverageDistanceAlgorithm ada = new AverageDistanceAlgorithm(bfa.getTargets(), bfa.getStart(), bfa.getEnd());
		
		start = end;
		end = System.currentTimeMillis();
		
		bestOrderEver = ada.getOrder();
		//shortestDEver = ada.shortestD;
		
		//We are only running genetic algorithm one time to save time, you can always do more times for maximum accuracy
		//Note: More accuracy means more computing time
		//For the next line just change the second argument to i < # where # is the amount of times you would like it to try
		for (int i = 0; i < Vertexes; i++) {
			turns = 0;
			
			//If you wish to increase rounds, please do it beforehand
			for (int j = 0; j < ROUNDS; j++) {
				Thread thread = new Thread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						GeneticAlgorithm ga = new GeneticAlgorithm(bfa.getTargets(), bfa.getStart(), bfa.getEnd(), determinator);
						
						if (determinator) {
							for (int k = 0; k < ga.POPSIZE; k++) {
								ga.population.add(bestOrderEver);
							}
						}
						
						ga.start();
						
						if (ga.shortestD < shortestDEver) {
							shortestDEver = ga.shortestD;
							bestOrderEver = ga.bestOrder;
						}
						
						generations += ga.getGeneration();
						
						turns++;
					}
					
				});
				
				
				thread.start();
			}
			
			while (turns < ROUNDS) {
				
			}
			
			determinator = true;
		}
		
		for (int i = 0; i < Vertexes * 2; i++) {
			RapidSwitchAlgorithm rsa = new RapidSwitchAlgorithm(bfa.getTargets(), bfa.getStart(), bfa.getEnd(), bestOrderEver);
			rsa.start();
			bestOrderEver = rsa.getBestOrder();
			shortestDEver = rsa.getShortestD();
		}
		
		//Again, if you wish to see the result, you can uncomment the following
		
		//System.out.println(String.format("Relative Best Order: %s", bestOrderEver.toString()));
		//System.out.println(String.format("Relative Distance: %.0f", shortestDEver));
		//System.out.println(String.format("Tried %d Generations", generations));
		
		
		start = end;
		end = System.currentTimeMillis();
		
		
		//System.out.println(String.format("Absolute Best Order: %s", bfa.getBestOrder()));
		//System.out.println(String.format("Relative Best Order: %s", bestOrderEver.toString()));
		
		//Uncomment it to see the runtime
		System.out.println(String.format("Time Used: %s seconds", (end - start) / 1000d).toString());
		
		if (bruteDistance == shortestDEver) {
			System.out.println("Perfect!");
			status = 1;
		} else if (shortestDEver - bruteDistance <= 3) {
			System.out.println("Great!");
			status = 2;
		} else if (shortestDEver - bruteDistance <= 5) {
			System.out.println("Okay");
			status = 3;
		} else {
			System.out.println("F NO! " + (shortestDEver - bruteDistance));
			status = 4;
		}
	}
	
	public int getStatus() {
		return status;
	}
}
