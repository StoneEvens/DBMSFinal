import java.util.ArrayList;
import java.util.Collections;

public class GeneticAlgorithm {
	private ArrayList<Vertice> targets;
	ArrayList<Integer> bestOrder;
	private Vertice start, end;
	private int generation;
	double shortestD = 1000;
	
	
	protected ArrayList<ArrayList<Integer>> population;
	protected ArrayList<Double> scores;
	protected double totalDistance;
	
	//You may mess around with the population size, the gap, and the mutate rate
	//Larger population size means more likely to find the absolute best solution, but at a cost of time
	//Gap means the number of generations that needs to be the same, if the best solution found is the same for 50 generations, it is likely that it is the best solution
	//Larger gap means the program will run more times to check if anything could be done better, but at a cost of time
	//Mutate rate is the probability for two places to be swapped by their order, in my own testing 0.3 is the best
	protected final int POPSIZE = 50;
	protected final int gap = 50;
	protected final double MUTATERATE = 0.1;
	protected int lastModifyGen;
	
	protected ArrayList<ArrayList<Double>> distances;
	
	public GeneticAlgorithm(int count) {
		targets = new ArrayList<Vertice>();
		generation = 0;
		lastModifyGen = 0;
		
		population = new ArrayList<ArrayList<Integer>>();
		scores = new ArrayList<Double>();
		bestOrder = new ArrayList<Integer>();
		
		start = new Vertice(Character.toString('x'), Math.floor(Math.random()*50), Math.floor(Math.random()*50));
		end = new Vertice(Character.toString('y'), Math.floor(Math.random()*50), Math.floor(Math.random()*50));
		
		ArrayList<Integer> order = new ArrayList<Integer>();
		
		//Create Points
		for (int i = 0; i < count; i++) {
			targets.add(new Vertice(Character.toString('a' + i), Math.floor(Math.random()*50), Math.floor(Math.random()*50)));
			order.add(i);
		}
		
		//Initial Trials
		for (int j = 0; j < POPSIZE; j++) {
			population.add(new ArrayList<Integer>(order));
			shuffle(population.get(j), 10);
		}
	}
	
	//For Debug Only
	public GeneticAlgorithm(ArrayList<Vertice> targets, Vertice start, Vertice end, boolean givenPopulation) {
		
		AverageDistanceAlgorithm ada = new AverageDistanceAlgorithm(targets, start, end);
		ada.getOrder();
		
		generation = 0;
		lastModifyGen = 0;
		
		population = new ArrayList<ArrayList<Integer>>();
		scores = new ArrayList<Double>();
		bestOrder = new ArrayList<Integer>();
		
		this.start = start;
		this.end = end;
		
		//ArrayList<Integer> order = new ArrayList<Integer>();
		
		//Create Points
		this.targets = targets;
		//for (int i = 0; i < targets.size(); i++) {
			//order.add(i);
		//}
		
		//Calculate Distances
		int count = targets.size();
		distances = new ArrayList<ArrayList<Double>>();
		for (int i = 0; i < count + 2; i++) {
			ArrayList<Double> temp = new ArrayList<Double>();
			
			if (i < count) {
				for (int j = i + 1; j < count; j++) {
					temp.add((double) Math.round(Math.abs(targets.get(i).getRow() - targets.get(j).getRow()) + Math.abs(targets.get(i).getColumn() - targets.get(j).getColumn())));
				}
			} else {
				if (i == count) {
					for (int j = 0; j < count; j++) {
						temp.add((double) Math.round(Math.abs(start.getRow() - targets.get(j).getRow()) + Math.abs(start.getColumn() - targets.get(j).getColumn())));
					}
				} else {
					for (int j = 0; j < count; j++) {
						temp.add((double) Math.round(Math.abs(end.getRow() - targets.get(j).getRow()) + Math.abs(end.getColumn() - targets.get(j).getColumn())));
					}
				}
			}
			
			distances.add(temp);
		}
		
		//Initial Trials
		//for (int j = 0; j < POPSIZE; j++) {
			//population.add(ada.getOrder());
			//shuffle(population.get(j), 10);
		//}
	}
	
	
	public ArrayList<Integer> start() {
		while (true) {
			generation++;
			calculateScores();
			normalizeScores();
			population = nextGeneration();
			
			if (generation - lastModifyGen > gap) {
				RapidSwitchAlgorithm rsa = new RapidSwitchAlgorithm(targets, start, end, bestOrder);
				rsa.start();
				
				shortestD = rsa.getShortestD();
				
				return rsa.getBestOrder();
			}
			
			//System.out.println("Alive Proof");
		}
	}
	
	
	protected void shuffle(ArrayList<Integer> list, int times) {
		for (int i = 0; i < times; i++) {
			int indexA = (int) Math.floor(Math.random()*list.size());
			int indexB = (int) Math.floor(Math.random()*list.size());
			
			int temp = list.get(indexA);
			list.set(indexA, list.get(indexB));
			list.set(indexB, temp);
		}
	}
	
	protected double calculateDistance(ArrayList<Integer> order) {
		double d = Math.round(Math.hypot(start.getRow() - targets.get(order.get(0)).getRow(), start.getColumn() - targets.get(order.get(0)).getColumn()));
		
		for (int i = 0; i < order.size() - 1; i++) {
			int k = order.get(i);
			int l = order.get(i + 1);
			d += Math.round(Math.hypot(targets.get(k).getRow() - targets.get(l).getRow(), targets.get(k).getColumn() - targets.get(l).getColumn()));
		}
		
		d += Math.round(Math.hypot(end.getRow() - targets.get(order.get(order.size() - 1)).getRow(), end.getColumn() - targets.get(order.get(order.size() - 1)).getColumn()));
		
		return d;
	}
	
	protected double calculateXYDistance(ArrayList<Integer> order) {
		//double d = Math.round(Math.abs(start.getRow() - targets.get(order.get(0)).getRow()) + Math.abs(start.getColumn() - targets.get(order.get(0)).getColumn()));
		double d = distances.get(order.size()).get(order.get(0));
		
		/*
		for (int i = 0; i < order.size() - 1; i++) {
			int k = order.get(i);
			int l = order.get(i + 1);
			d += Math.round(Math.abs(targets.get(k).getRow() - targets.get(l).getRow()) + Math.abs(targets.get(k).getColumn() - targets.get(l).getColumn()));
		}
		
		d += Math.round(Math.abs(end.getRow() - targets.get(order.get(order.size() - 1)).getRow()) + Math.abs(end.getColumn() - targets.get(order.get(order.size() - 1)).getColumn()));
		*/
		
		for (int i = 0; i < order.size() - 1; i++) {
			int k = order.get(i);
			int l = order.get(i + 1);
			
			if (k > l) {
				int temp = k;
				k = l;
				l = temp;
			}
			
			d += distances.get(k).get(l - k - 1);
		}
		
		d += distances.get(order.size() + 1).get(order.get(order.size() - 1));
		
		if (d < shortestD) {
			bestOrder.clear();
			bestOrder.addAll(order);
			shortestD = d;
		}

		return d;
	}
	
	protected void calculateScores() {
		totalDistance = 0;
		
		for (ArrayList<Integer> list: population) {
			/*
			System.out.print(start.getName() + " ");
			for (int i: list) {
				System.out.print(targets.get(i).getName() + " ");
			}
			System.out.print(end.getName() + " \n");
			*/
			
			double score = calculateDistance(list);
			scores.add(score);
			totalDistance += score;
			
			if (score < shortestD) {
				shortestD = score;
				bestOrder = list;
				lastModifyGen = generation;
			}
		}
	}
	
	protected void normalizeScores() {
		for (double distance: scores) {
			distance = (distance / totalDistance);
		}
	}
	
	protected ArrayList<ArrayList<Integer>> nextGeneration() {
		ArrayList<ArrayList<Integer>> newPopulation = new ArrayList<ArrayList<Integer>>();
		
		for (int i = 0; i < population.size(); i++) {
			ArrayList<Integer> newOrder = crossover(pickFrom(population, scores), pickFrom(population, scores));
			
			mutate(newOrder);
			
			newPopulation.add(newOrder);
		}
		
		return newPopulation;
	}
	
	protected ArrayList<Integer> pickFrom(ArrayList<ArrayList<Integer>> gList, ArrayList<Double> pList) {
		int index = 0;
		double p = Math.random();
		
		while (p > 0) {
			p = p - pList.get(index);
			index++;
		}
		
		index--;
		return gList.get(index);
	}
	
	protected ArrayList<Integer> crossover(ArrayList<Integer> order1, ArrayList<Integer> order2) {
		int startIndex = (int) Math.floor(Math.random()*order1.size());
		int endIndex = startIndex + (int) Math.floor(Math.random()*(order1.size() - startIndex));
		
		ArrayList<Integer> newOrder = new ArrayList<Integer>(order1.subList(startIndex, endIndex));
		
		for (int j: order2) {
			if (!newOrder.contains(j)) {
				newOrder.add(j);
			}
		}
		
		//System.out.println(order1 + "" + order2 + "" + newOrder);
		
		return newOrder;
	}
	
	protected void mutate(ArrayList<Integer> order) {
		for (int i = 0; i < order.size(); i++) {
			double p = Math.random();
			
			if (p < MUTATERATE) {
				int indexA = (int) Math.floor(Math.random()*order.size());
				//int indexB = (int) Math.floor(Math.random()*order.size());
				int pos = (int) Math.floor(Math.random()*(order.size() - 1));
				
				int temp = order.get(indexA);
				//order.set(indexA, order.get(indexB));
				//order.set(indexB, temp);
				order.remove(indexA);
				order.add(pos, temp);
			}
			
			if (p > (0.9)) {
				//Collections.reverse(order);
				int indexA = (int) Math.floor(Math.random()*order.size());
				int length = (int) Math.floor(Math.random()*(order.size() - indexA));
				
				ArrayList<Integer> tempList = new ArrayList<Integer>(order.subList(indexA, indexA + length));
				//order.set(indexA, order.get(indexB));
				//order.set(indexB, temp);
				order.removeAll(tempList);
				Collections.reverse(tempList);
				order.addAll(indexA, tempList);
			}
		}
	}
	
	public int getGeneration() {
		return generation;
	}
	
	public void setPopulation(ArrayList<ArrayList<Integer>> population) {
		this.population = population;
	}
}