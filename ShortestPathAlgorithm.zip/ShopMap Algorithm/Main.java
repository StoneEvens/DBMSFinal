import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int totalSuccess = 0;
		int totalGood = 0;
		int totalOkay = 0;
		int totalTrial = 0;
		int status = 0;
		Queue<ArrayList<Integer>> fUpQueue = new LinkedList<ArrayList<Integer>>();
		
		//You can change the status to be less than 3(2 units of error) or 4 (3 units or more)
		//So the program will stop running when one of your selection happens
		//Note: This can keep your computer running for a long time since I haven't seen an error of 2 or above ever
		while (status < 50) {
			TestClass tc = new TestClass();
			
			switch(tc.getStatus()) {
			case 0:
				System.out.println("Failed to execute!");
				break;
			case 1:
				totalSuccess++;
				break;
			case 2:
				totalGood++;
				break;
			case 3:
				totalOkay++;
				break;
			case 4:
				fUpQueue.add(tc.bfa.getBestOrder());
				fUpQueue.add(tc.bestOrderEver);
			}
			
			totalTrial++;
			
			//If you wish to keep it running for a long while, uncomment the following and comment out the status++
			//status = tc.getStatus();
			status++;
		}
		
		System.out.println("----------------------------------------");
		
		System.out.printf("Perfect Rate: %d Percent\n", (int)totalSuccess*100/totalTrial);
		System.out.printf("Great Rate: %d Percent\n", (int)totalGood*100/totalTrial);
		System.out.printf("Okay Rate: %d Percent\n", (int)totalOkay*100/totalTrial);
		System.out.printf("Overall Success Rate: %d Percent\n", (int) (totalSuccess + totalGood + totalOkay)*100 / totalTrial);
		System.out.printf("Total Trial: %d\n", totalTrial);
		
		System.out.println("----------------------------------------");
		
		while (!fUpQueue.isEmpty()) {
			System.out.println("Absolute Shortest: " + fUpQueue.poll());
			System.out.println("Fed Up Shortest D: " + fUpQueue.poll());
			System.out.println();
		}
	}
}
