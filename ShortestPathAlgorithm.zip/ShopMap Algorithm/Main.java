
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int totalSuccess = 0;
		int totalGood = 0;
		int totalOkay = 0;
		int totalTrial = 0;
		int status = 0;
		
		//You can change the status to be less than 3(2 units of error) or 4 (3 units or more)
		//So the program will stop running when one of your selection happens
		//Note: This can keep your computer running for a long time since I haven't seen an error of 2 or above ever
		while (status < 200) {
			TestClass tc = new TestClass();
			
			switch(tc.getStatus()) {
			case 0:
				System.out.println("Failed to execute!");
				break;
			case 1:
				totalSuccess++;
				break;
			case 2:
				totalGood++;
				break;
			case 3:
				totalOkay++;
				break;
			}
			
			totalTrial++;
			
			//If you wish to keep it running for a long while, uncomment the following and comment out the status++
			//status = tc.getStatus();
			status++;
		}
		
		System.out.printf("Perfect Rate: %d Percent\n", (int)totalSuccess*100/totalTrial);
		System.out.printf("Great Rate: %d Percent\n", (int)totalGood*100/totalTrial);
		System.out.printf("Okay Rate: %d Percent\n", (int)totalOkay*100/totalTrial);
		System.out.printf("Overall Success Rate: %d Percent\n", (int) (totalSuccess + totalGood + totalOkay)*100 / totalTrial);
		System.out.printf("Total Trial: %d", totalTrial);
	}
}
