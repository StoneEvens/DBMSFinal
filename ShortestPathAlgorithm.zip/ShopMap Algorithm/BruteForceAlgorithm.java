import java.util.ArrayList;
import java.util.Stack;

public class BruteForceAlgorithm {
	private ArrayList<Vertice> targets;
	private ArrayList<Integer> order;
	private Vertice start, end;
	private int count;
	private ArrayList<Integer> bestOrder;
	public double shortestD = 1000;
	
	public ArrayList<ArrayList<Double>> distances;
	
	public BruteForceAlgorithm(int count) {
		targets = new ArrayList<Vertice>();
		order = new ArrayList<Integer>();
		bestOrder = new ArrayList<Integer>();
		this.count = 0;
		
		start = new Vertice(Character.toString('x'), Math.floor(Math.random()*50), Math.floor(Math.random()*50));
		end = new Vertice(Character.toString('y'), Math.floor(Math.random()*50), Math.floor(Math.random()*50));
		
		for (int i = 0; i < count; i++) {
			targets.add(new Vertice(Character.toString('a' + i), Math.floor(Math.random()*50), Math.floor(Math.random()*50)));
			order.add(i);
		}
		
		distances = new ArrayList<ArrayList<Double>>();
		getDistances(count);
		
		for (ArrayList<Double> list: distances) {
			for (double d: list) {
				//System.out.print(d + " ");
			}
			
			//System.out.println();
		}
	}
	
	public BruteForceAlgorithm(ArrayList<Vertice> targets, Vertice start, Vertice end) {
		this.targets = targets;
		order = new ArrayList<Integer>();
		bestOrder = new ArrayList<Integer>();
		this.count = 0;
		
		this.start = start;
		this.end = end;
		
		for (int i = 0; i < targets.size(); i++) {
			order.add(i);
		}
		
		//System.out.println(this.targets.size());
		
		if (!targets.isEmpty()) {
			distances = new ArrayList<ArrayList<Double>>();
			getDistances(targets.size());
			
			for (ArrayList<Double> list: distances) {
				for (double d: list) {
					//System.out.print(d + " ");
				}
				
				//System.out.println();
			}
		}
	}
	
	protected void getDistances(int count) {
		for (int i = 0; i < count + 2; i++) {
			ArrayList<Double> temp = new ArrayList<Double>();
			
			if (i < count) {
				for (int j = i + 1; j < count; j++) {
					temp.add((double) Math.round(Math.hypot(targets.get(i).getRow() - targets.get(j).getRow(), targets.get(i).getColumn() - targets.get(j).getColumn())));
				}
			} else {
				if (i == count) {
					for (int j = 0; j < count; j++) {
						temp.add((double) Math.round(Math.hypot(start.getRow() - targets.get(j).getRow(), start.getColumn() - targets.get(j).getColumn())));
					}
				} else {
					for (int j = 0; j < count; j++) {
						temp.add((double) Math.round(Math.hypot(end.getRow() - targets.get(j).getRow(), end.getColumn() - targets.get(j).getColumn())));
					}
				}
			}
			
			distances.add(temp);
		}
	}
	
	public ArrayList<Integer> start() {
		if (targets.isEmpty()) {
			return order;
		} else {
			while (true) {
				/*
				System.out.print(start.getName() + " ");
				for (int i: order) {
					System.out.print(targets.get(i).getName() + " ");
				}
				System.out.print(end.getName() + " \n");
				*/
				
				count++;
				
				calculateDistance();
				
				if (!nextOrder()) {
					return bestOrder;
				}
			}
		}
	}
	
	private void calculateDistance() {
		//double d = Math.round(Math.abs(start.getRow() - targets.get(order.get(0)).getRow()) + Math.abs(start.getColumn() - targets.get(order.get(0)).getColumn()));
		double d = distances.get(order.size()).get(order.get(0));
		
		/*
		for (int i = 0; i < order.size() - 1; i++) {
			int k = order.get(i);
			int l = order.get(i + 1);
			d += Math.round(Math.abs(targets.get(k).getRow() - targets.get(l).getRow()) + Math.abs(targets.get(k).getColumn() - targets.get(l).getColumn()));
		}
		
		d += Math.round(Math.abs(end.getRow() - targets.get(order.get(order.size() - 1)).getRow()) + Math.abs(end.getColumn() - targets.get(order.get(order.size() - 1)).getColumn()));
		*/
		
		for (int i = 0; i < order.size() - 1; i++) {
			int k = order.get(i);
			int l = order.get(i + 1);
			
			if (k > l) {
				int temp = k;
				k = l;
				l = temp;
			}
			
			d += distances.get(k).get(l - k - 1);
		}
		
		d += distances.get(order.size() + 1).get(order.get(order.size() - 1));
		
		if (d < shortestD) {
			bestOrder.clear();
			bestOrder.addAll(order);
			shortestD = d;
		}
	}
	
	public boolean nextOrder() {
		int largestI = -1;
		int largestJ = -1;
		
		//Largest I
		for (int i = 0; i < order.size() - 1; i++) {
			if (order.get(i) < order.get(i + 1)) {
				largestI = i;
			}
		}
		
		if (largestI == -1) {
			return false;
		}
		
		//Largest J
		for (int j = 0; j < order.size(); j++) {
			if (order.get(largestI) < order.get(j)) {
				largestJ = j;
			}
		}
		
		//Swap
		int temp = order.get(largestI);
		order.set(largestI, order.get(largestJ));
		order.set(largestJ, temp);
		
		//Reverse
		Stack<Integer> reverser = new Stack<Integer>();
		reverser.addAll(order.subList(largestI + 1, order.size() - 1));
		order.removeAll(order.subList(largestI + 1, order.size() - 1));
		
		while (!reverser.isEmpty()) {
			order.add(reverser.pop());
		}
		
		return true;
	}
	
	public int getCount() {
		return count;
	}
	
	//For Debug Only
	public ArrayList<Vertice> getTargets() {
		return targets;
	}
	
	public Vertice getStart() {
		return start;
	}
	
	public Vertice getEnd() {
		return end;
	}
}
