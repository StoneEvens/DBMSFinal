import java.util.ArrayList;
import java.util.Collections;

public class RapidSwitchAlgorithm {
	private ArrayList<Vertice> targets;
	private ArrayList<Integer> order, bestOrder;
	private Vertice start, end;
	private double shortestD = 1000;
	
	public RapidSwitchAlgorithm(ArrayList<Vertice> targets, Vertice start, Vertice end, ArrayList<Integer> order) {
		this.targets = targets;
		this.start = start;
		this.end = end;
		this.order = order;
		this.bestOrder = order;
		
		shortestD = calculateDistance(this.order);
	}
	
	public void start() {
		for (int i = 0; i < order.size(); i++) {
			for (int j = i; j < order.size(); j++) {
				ArrayList<Integer> tempOrder = new ArrayList<Integer>(order);
				ArrayList<Integer> tempList = new ArrayList<Integer>(tempOrder.subList(i, j));
				tempOrder.removeAll(tempList);
				Collections.reverse(tempList);
				tempOrder.addAll(i, tempList);
				
				double d = calculateDistance(tempOrder);
				
				if (d <= shortestD) {
					shortestD = d;
					bestOrder = tempOrder;
				}
			}
		}
	}
	
	public ArrayList<Integer> getBestOrder() {
		return bestOrder;
	}
	
	public double getShortestD() {
		return shortestD;
	}
	
	protected double calculateDistance(ArrayList<Integer> order) {
		double d = Math.round(Math.hypot(start.getRow() - targets.get(order.get(0)).getRow(), start.getColumn() - targets.get(order.get(0)).getColumn()));
		
		for (int i = 0; i < order.size() - 1; i++) {
			int k = order.get(i);
			int l = order.get(i + 1);
			d += Math.round(Math.hypot(targets.get(k).getRow() - targets.get(l).getRow(), targets.get(k).getColumn() - targets.get(l).getColumn()));
		}
		
		d += Math.round(Math.hypot(end.getRow() - targets.get(order.get(order.size() - 1)).getRow(), end.getColumn() - targets.get(order.get(order.size() - 1)).getColumn()));
		
		return d;
	}
}
