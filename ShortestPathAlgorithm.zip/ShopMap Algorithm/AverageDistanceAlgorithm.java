import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class AverageDistanceAlgorithm {
	private ArrayList<Vertice> targets;
	private ArrayList<Integer> order;
	private Vertice start, end;
	public double shortestD = 1000;
	
	public ArrayList<double[]> distances;
	
	public AverageDistanceAlgorithm(ArrayList<Vertice> targets, Vertice start, Vertice end) {
		this.targets = targets;
		this.start = start;
		this.end = end;
		order = new ArrayList<Integer>();
		distances = new ArrayList<double[]>();
		
		if (!targets.isEmpty()) {
			calculateAverageDistance();
			Collections.sort(distances, Comparator.comparingDouble(a -> a[1]));
			/*
			for (double[] da: distances) {
				for (double d: da) {
					System.out.print(d + ", ");
				}
				
				System.out.println();
			}
			*/
			computeOrderTest();
			
			//System.out.println(order);
			calculateTotalDistance();
		}
	}
	
	private void calculateAverageDistance() {
		for (Vertice v: targets) {
			double d1 = Math.round(Math.hypot(start.getRow() - v.getRow(), start.getColumn() - v.getColumn())) + 1;
			double d2 = Math.round(Math.hypot(end.getRow() - v.getRow(), end.getColumn() - v.getColumn())) + 1;
			
			double[] ds = new double[4];
			ds[0] = (double) targets.indexOf(v);
			ds[1] = (d1 * d2);
			ds[2] = d1;
			ds[3] = d2;
			
			distances.add(ds);
			
			//System.out.println(d1 + ", " + d2 + ", " + (d1 + d2));
		}
	}
	
	private void computeOrder() {
		ArrayList<double[]> leftOrder = new ArrayList<double[]>();
		ArrayList<double[]> rightOrder = new ArrayList<double[]>();
		
		for (double[] da: distances) {
			if (da[2] <= da[3]) {
				leftOrder.add(da);
			} else {
				rightOrder.add(da);
			}
		}
		
		Collections.sort(leftOrder, Comparator.comparingDouble(a -> a[2]));
		Collections.sort(rightOrder, Comparator.comparingDouble(a -> a[3]));
		Collections.reverse(rightOrder);
		
		for (double[] da: leftOrder) {
			order.add((int) da[0]);
		}
		
		for (double[] da: rightOrder) {
			order.add((int) da[0]);
		}
	}
	
	private void computeOrderTest() {
		ArrayList<Vertice> leftList = new ArrayList<Vertice>();
		ArrayList<Integer> leftOrder = new ArrayList<Integer>();
		ArrayList<Vertice> rightList = new ArrayList<Vertice>();
		ArrayList<Integer> rightOrder = new ArrayList<Integer>();
		
		for (int i = 0; i < distances.size() - 1; i++) {
			if (distances.get(i)[2] < distances.get(i)[3]) {
				leftList.add(targets.get((int)distances.get(i)[0]));
				leftOrder.add((int)distances.get(i)[0]);
			} else {
				rightList.add(targets.get((int)distances.get(i)[0]));
				rightOrder.add((int)distances.get(i)[0]);
			}
		}
		
		Vertice furthest = targets.get((int)distances.get(distances.size() - 1)[0]);
		
		if (leftList.size() > 10) {
			AverageDistanceAlgorithm adal = new AverageDistanceAlgorithm(leftList, start, furthest);
			leftOrder = adal.getOrder();
		} else {
			BruteForceAlgorithm bfal = new BruteForceAlgorithm(leftList, start, furthest);
			leftOrder = bfal.start();
		}
		
		if (rightList.size() > 10) {
			AverageDistanceAlgorithm adar = new AverageDistanceAlgorithm(rightList, furthest, end);
			rightOrder = adar.getOrder();
		} else {
			BruteForceAlgorithm bfar = new BruteForceAlgorithm(rightList, furthest, end);
			rightOrder = bfar.start();
		}
		
		//BruteForceAlgorithm bfal = new BruteForceAlgorithm(leftList, start, furthest);
		//BruteForceAlgorithm bfar = new BruteForceAlgorithm(rightList, furthest, end);
		
		//leftOrder = bfal.start();
		//rightOrder = bfar.start();
		
		for (int i: leftOrder) {
			order.add(targets.indexOf(leftList.get(i)));
		}
		
		order.add(targets.indexOf(furthest));
		
		for (int j: rightOrder) {
			order.add(targets.indexOf(rightList.get(j)));
		}
	}
	
	public ArrayList<Integer> getOrder() {
		return order;
	}
	
	public void calculateTotalDistance() {
		double d = Math.round(Math.hypot(start.getRow() - targets.get(order.get(0)).getRow(), start.getColumn() - targets.get(order.get(0)).getColumn()));
		
		for (int i = 0; i < order.size() - 1; i++) {
			int k = order.get(i);
			int l = order.get(i + 1);
			d += Math.round(Math.hypot(targets.get(k).getRow() - targets.get(l).getRow(), targets.get(k).getColumn() - targets.get(l).getColumn()));
		}
		
		d += Math.round(Math.hypot(end.getRow() - targets.get(order.get(order.size() - 1)).getRow(), end.getColumn() - targets.get(order.get(order.size() - 1)).getColumn()));
		
		//System.out.println("Total Distance: " + d);
	}
}
