package com.beatgoogle.letsbeatgoogle;

import android.util.Log;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.TimeUnit;

public class Client{
    private Socket socket;
    private DataInputStream dis;
    private DataOutputStream dos;
    private String input;
    private boolean connected;
    private boolean update;
    private String ip;



    public Client() {
        ip = "192.168.168.125";
        connected = true;
        input = new String();

        getConnection();
    }

    public void getConnection() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                connected = true;

                try {
                    socket = new Socket(ip, 800);

                    dis = new DataInputStream(socket.getInputStream());
                    dos = new DataOutputStream(socket.getOutputStream());

                    String temp;
                    while (connected) {
                        temp = dis.readUTF();

                        if (!(temp.equals("") || temp.equals("Test_Connection"))) {
                            input = temp;
                        }

                        if (input.length() > 0) {
                            update = true;
                        }
                    }

                } catch (IOException e) {
                    connected = false;
                    try {
                        socket.close();
                    } catch (IOException e1) {

                    } catch (NullPointerException e2) {

                    }

                } catch (NullPointerException e3) {

                }
            }
        });

        thread.start();
    }

    public boolean sendOutput(String output) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!output.equals("")) {
                        dos.writeUTF(output);
                        dos.flush();
                    }
                } catch (IOException e1) {

                } catch (NullPointerException e2) {
                    update = true;
                }
            }
        });

        if (connected) {
            thread.start();
        }

        return true;
    }

    public boolean getConnected() {return connected;}

    public void setIp(String ip) {
        this.ip = ip;
    }

    public Queue<String> getString() {
        update = false;

        if (input.isEmpty()) {
            input = "Connection Failed, Please reconnect";
        }

        Queue<String> temp = new LinkedList<>(Arrays.asList(input.split("\n")));
        input = "";
        return temp;
    }

    public String getIp() {
        return ip;
    }

    public boolean getUpdate() {
        return update;
    }
}
