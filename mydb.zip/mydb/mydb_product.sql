-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `Shelf_ID` int NOT NULL,
  `Product_ID` int NOT NULL,
  `Product_Name` varchar(45) NOT NULL,
  `Product_Price` int DEFAULT NULL,
  `Product_Description` text,
  `Product_Pic` longblob,
  PRIMARY KEY (`Shelf_ID`,`Product_ID`),
  UNIQUE KEY `Product_Name_UNIQUE` (`Product_Name`),
  UNIQUE KEY `Product_ID_UNIQUE` (`Product_ID`),
  KEY `fk_Product_Shelf1_idx` (`Shelf_ID`),
  CONSTRAINT `fk_Product_Shelf1` FOREIGN KEY (`Shelf_ID`) REFERENCES `shelf` (`Shelf_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,101,'Chips',35,'Crispy, savory potato chips',NULL),(2,201,'Milk',53,'Fresh, nutritious milk',NULL),(3,301,'Chocolate',39,'Rich, creamy chocolate',NULL),(4,401,'Cake',40,'Moist, delicious cake',NULL),(5,501,'Banana',20,'Sweet, nutritious bananas',NULL),(6,601,'Salmon',200,'Fresh, premium salmon',NULL),(7,701,'Mango sorbet',35,'Refreshing mango sorbet',NULL),(8,801,'Sandwich icecream',80,'Creamy ice cream',NULL),(9,901,'Stinky tofu',35,'Traditional fermented tofu',NULL),(10,1001,'Rice',180,'Versatile, high-quality rice',NULL),(11,1101,'Kimchi',149,'Spicy, fermented Korean kimchi',NULL),(12,1201,'Jelly',46,'Sweet, fruity jelly',NULL),(13,1301,'Soy milk',32,'Smooth, nutritious soy milk',NULL),(14,1401,'Tissue',198,'Soft, absorbent tissues',NULL),(15,1501,'Instant noodle',43,'Quick and easy instant noodle',NULL),(16,1601,'Shampoo',98,'Nourishing shampoo',NULL);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-31 18:17:31
