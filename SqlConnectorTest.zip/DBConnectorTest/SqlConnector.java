import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class SqlConnector {
	private Connection conn;
	
	//Getters (Sql Commands)
	//store
	
	public SqlConnector () throws SQLException{
		String server = "jdbc:mysql://127.0.0.1:3306/";
		String database = "mydb"; // change to your own database
		String url = server + database + "?useSSL=false";
		String username = "root";
		String password = "CCHSteven0402011-";
		
		this.conn = DriverManager.getConnection(url, username, password);
		System.out.println("DB connected");
	}
	
	
	public String getStore(String Store_ID) {
		String Storeoutput = "";
		String query;
		boolean success;
	
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Total_Row, Total_Col, Entrance_ID, Exit_ID FROM `Store` WHERE Store_ID = '%s'", Store_ID);
			
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				result.next();
				
				Storeoutput = String.format("%s, %s, %s, %s", result.getString("Total_Row"), result.getString("Total_Col"), result.getString("Entrance_ID"), result.getString("Exit_ID"));	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Storeoutput;
	}
	
	//shelf	
	public ArrayList<String> getShelf(String Store_ID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;
		boolean success;
		
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Shelf_ID, AdjacentWalkway, `Col_No`, `Row_No` FROM `Shelf` WHERE `Store_ID` = '%s'", Store_ID);
				
				
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s, %s, %s, %s", result.getString("Shelf_ID"), result.getString("AdjacentWalkway"), result.getString("Col_No"), result.getString("Row_No")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	
	//product	
	public ArrayList<String> getProduct(String Product_ID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;
		boolean success;		
		
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Product_Name, Product_Price, Product_Description FROM `Product` WHERE Product_ID = '%s'", Product_ID);
				
				
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s, %s, %s", result.getString("Product_Name"), result.getString("Product_Price"), result.getString("Product_Description")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	
	//review	
	public ArrayList<String> getReview(String Product_ID, String Customer_ID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;
		boolean success;
			
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Review_Info FROM `Product_Review` WHERE Product_ID = '%s' AND Customer_ID = '%s'", Product_ID, Customer_ID);
					
					
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s", result.getString("Review_Info")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	
	//promotion	
	public String getPromotion(String Product_ID) {
		String Promotionoutput = "";
		String query;
		boolean success;
				
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Discount, Promotion_Date FROM `Product_Promotion` WHERE %s", Product_ID);
						
						
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				result.next();
				
				Promotionoutput = String.format("%s, %s", result.getString("Discount"), result.getString("Promotion_Date"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Promotionoutput;	
	}
	
	//history	
	public ArrayList<String> getHistory(String Product_ID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;
		boolean success;
					
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Price, Recorded_Time FROM `Product_Price_History` WHERE Product_ID = '%s'", Product_ID);
				
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s, %s", result.getString("Price"), result.getString("Recorded_Time")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;		
	}
	
	//Customer	
	public String getCustomer(String Customer_ID) {
		String Customeroutput = "";
		String query;
		boolean success;
						
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Customer_ID, User_ID FROM `Customer` WHERE Customer_ID = '%s'", Customer_ID);
				
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				result.next();
				
				Customeroutput = String.format("%s, %s", result.getString("Customer_ID"), result.getString("User_ID"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Customeroutput;	
	}
	
	//Intersection	
	public ArrayList<String> getIntersection(String Store_ID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;
		boolean success;
							
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Intersection_ID, Row_No, Col_No FROM `Intersection` WHERE Store_ID = '%s'", Store_ID);
					
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s, %s, %s", result.getString("Intersection_ID"), result.getString("Row_No"), result.getString("Col_No")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;	
	}
	
	//employee
	public boolean findEmployee(String Emp_ID) {
		String query = String.format("SELECT Employee_ID FROM Employee WHERE Employee_ID = %s", Emp_ID);
		boolean success;
		
		try (Statement stat = conn.createStatement()){
			success = stat.execute(query);
			
			if (success) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	//Setters (Sql Commands)
	//These may not be used
	//updateProduct
	public void updateProduct(String Shelf_ID, String Product_ID) {
		String query = String.format("UPDATE `Product` SET `Shelf_ID`='%s' WHERE Product__ID = '%s'", Shelf_ID, Product_ID);
			
		try (Statement stat = conn.createStatement()){
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//insertProduct	
	public void insertProduct(String Product_ID, String Shelf_ID, String Product_Name, String Product_Price, String Product_Description) {
		String query = String.format("INSERT INTO `Product`(`Product_ID`, `Shelf_ID`, `Product_Name`, `Product_Price`, `Product_Description`) VALUES ('%s', `%s`, `%s`, %d,`%s`)", Product_ID, Shelf_ID, Product_Name, Product_Price, Product_Description);
				
		try (Statement stat = conn.createStatement()){
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//updatePromotion
	public void updatePromotion(String Product_ID, int Discount, String Promotion_Date) {
		String query = String.format("UPDATE `Promotion` SET `Discount`= %d, `Promotion_Date = `%s`` WHERE Product__ID = '%s'", Discount, Promotion_Date, Product_ID);
					
		try (Statement stat = conn.createStatement()){
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//insertPromotion
	public void insertPromotion(String Product_ID, int Discount, String Promotion_Date) {
		String query = String.format("INSERT INTO `Promotion`(`Product_ID`, `Discount`, `Promotion_Date`) VALUES ('%s', %d,`%s`)", Product_ID, Discount, Promotion_Date);
				
		try (Statement stat = conn.createStatement()){
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}