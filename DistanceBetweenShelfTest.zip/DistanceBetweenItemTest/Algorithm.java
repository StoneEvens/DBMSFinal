import java.util.ArrayList;

public class Algorithm {
	//private final Map map;
	//private ArrayList<Aisle> aisles;
	private ArrayList<Shelf> targets;
	private ArrayList<ArrayList<Integer>> distances;
	
	public Algorithm(ArrayList<Shelf> targets) {
		//this.map = map;
		//this.aisles = this.map.getAisles();
		this.targets = targets;
		
		distances = new ArrayList<ArrayList<Integer>>();
	}
	
	public void calculateDistances() {
		for (int i = 0; i < targets.size() - 1; i++) {
			ArrayList<Integer> dpr = new ArrayList<Integer>();
			
			for (int j = i + 1; j < targets.size(); j++) {
				//Check the shortest distance between any two products searched
				
				//Instantiate 4 intersections (two for each aisle, where the two products are placed on)
				Intersection startItsc1 = targets.get(i).getWkwy().getAisle().getItsc1();
				Intersection startItsc2 = targets.get(i).getWkwy().getAisle().getItsc2();
				Intersection endItsc1 = targets.get(j).getWkwy().getAisle().getItsc1();
				Intersection endItsc2 = targets.get(j).getWkwy().getAisle().getItsc2();
				
				//Find which combination is the shortest
				int[] d = new int[4];
				
				//Make sure to include both the distance between aisles and distances between products its corresponding intersection
				//Don't worry too much about these, these are basically splitting the total distance into the distance between the aisles and the distance between the shelf and the adjacent intersection compared with
				//int dBtnAisle = 0;
				
				d[0] = Math.abs(startItsc1.getRow() - endItsc1.getRow()) + Math.abs(startItsc1.getCol() - endItsc1.getCol());
				d[1] = Math.abs(startItsc1.getRow() - endItsc2.getRow()) + Math.abs(startItsc1.getCol() - endItsc2.getCol());
				d[2] = Math.abs(startItsc2.getRow() - endItsc1.getRow()) + Math.abs(startItsc2.getCol() - endItsc1.getCol());
				d[3] = Math.abs(startItsc2.getRow() - endItsc2.getRow()) + Math.abs(startItsc2.getCol() - endItsc2.getCol());
				
				if (!targets.get(i).getWkwy().getAisle().equals(targets.get(j).getWkwy().getAisle())) {
					d[0] += Math.abs(startItsc1.getRow() - targets.get(i).getWkwy().getRow()) + Math.abs(endItsc1.getRow() - targets.get(j).getWkwy().getRow()) + Math.abs(startItsc1.getCol() - targets.get(i).getWkwy().getCol()) + Math.abs(endItsc1.getCol() - targets.get(j).getWkwy().getCol());
					d[1] += Math.abs(startItsc1.getRow() - targets.get(i).getWkwy().getRow()) + Math.abs(endItsc2.getRow() - targets.get(j).getWkwy().getRow()) + Math.abs(startItsc1.getCol() - targets.get(i).getWkwy().getCol()) + Math.abs(endItsc2.getCol() - targets.get(j).getWkwy().getCol());
					d[2] += Math.abs(startItsc2.getRow() - targets.get(i).getWkwy().getRow()) + Math.abs(endItsc1.getRow() - targets.get(j).getWkwy().getRow()) + Math.abs(startItsc2.getCol() - targets.get(i).getWkwy().getCol()) + Math.abs(endItsc1.getCol() - targets.get(j).getWkwy().getCol());
					d[3] += Math.abs(startItsc2.getRow() - targets.get(i).getWkwy().getRow()) + Math.abs(endItsc2.getRow() - targets.get(j).getWkwy().getRow()) + Math.abs(startItsc2.getCol() - targets.get(i).getWkwy().getCol()) + Math.abs(endItsc2.getCol() - targets.get(j).getWkwy().getCol());
				} else {
					d[0] += Math.abs(targets.get(i).getWkwy().getRow() - targets.get(j).getWkwy().getRow()) + Math.abs(targets.get(i).getWkwy().getCol() - targets.get(j).getWkwy().getCol());
					d[1] += Math.abs(targets.get(i).getWkwy().getRow() - targets.get(j).getWkwy().getRow()) + Math.abs(targets.get(i).getWkwy().getCol() - targets.get(j).getWkwy().getCol());
					d[2] += Math.abs(targets.get(i).getWkwy().getRow() - targets.get(j).getWkwy().getRow()) + Math.abs(targets.get(i).getWkwy().getCol() - targets.get(j).getWkwy().getCol());
					d[3] += Math.abs(targets.get(i).getWkwy().getRow() - targets.get(j).getWkwy().getRow()) + Math.abs(targets.get(i).getWkwy().getCol() - targets.get(j).getWkwy().getCol());
				}
				
				int shortestD = d[0];
				
				for (int l: d) {
					if (l < shortestD) {
						shortestD = l;
					}
				}
				
				dpr.add(shortestD);
			}
			
			distances.add(dpr);
		}
	}
	
	public ArrayList<ArrayList<Integer>> getDistances() {
		return distances;
	}
}
