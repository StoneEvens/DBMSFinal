
public class Shelf extends MapElement{
	private Walkway nearestWkwy;
	
	public Shelf() {
		this.row = -1;
		this.col = -1;
		this.name = "DNE";
		this.nearestWkwy = new Walkway();
	}
	
	public Shelf(String name, int row, int col, Walkway wkwy) {
		this.row = row;
		this.col = col;
		this.name = name;
		this.nearestWkwy = wkwy;
	}
	
	public void setNearestWkwy(Walkway wkwy) {
		this.nearestWkwy = wkwy;
	}
	
	public Walkway getWkwy() {
		return nearestWkwy;
	}
}
