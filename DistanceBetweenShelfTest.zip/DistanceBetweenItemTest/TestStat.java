import java.util.ArrayList;

public class TestStat {
	int shelfRows, shelfCols;
	int[] dimension;
	ArrayList<Coordinate> itscs, shelves, wkwys;
	
	public TestStat() {
		dimension = new int[2];
		itscs = new ArrayList<Coordinate>();
		shelves = new ArrayList<Coordinate>();
		wkwys = new ArrayList<Coordinate>();
		
		dimension[0] = 7;
		dimension[1] = 7;
		
		for (int i = 0; i < dimension[0]; i++) {
			for (int j = 0; j < dimension[1]; j++) {
				if (i%3 == 0 || j%3 == 0) {
					if (i%3 == 0 && j%3 == 0) {
						itscs.add(new Coordinate(i, j));
					} else {
						wkwys.add(new Coordinate(i, j));
					}
				} else {
					shelves.add(new Coordinate(i, j));
				}
			}
		}
	}
}
