import java.util.ArrayList;

public class Map {
	ArrayList<Aisle> aisles;
	MapElement[][] mapElements;
	
	public Map() {
		aisles = new ArrayList<Aisle>();
		
		getData();
	}
	
	private void getData() {
		//Get data from SQL (Using TestStat class for test)
		TestStat ts = new TestStat();
		
		//Instantiate mapElements
		mapElements = new MapElement[ts.dimension[0]][ts.dimension[1]];
		
		//Always Create Intersection First
		for (Coordinate c: ts.itscs) {
			Intersection i = new Intersection("Itsc", c.getRow(), c.getCol());
			
			//itscs.add(i);
			mapElements[c.getRow()][c.getCol()] = i;
		}
		
		//Create Walkways
		for (Coordinate c: ts.wkwys) {
			Walkway w = new Walkway("Wkwy", c.getRow(), c.getCol(), new Aisle());
			
			mapElements[c.getRow()][c.getCol()] = w;
		}
		
		//Create Shelves
		int k = 0;
		
		for (Coordinate c: ts.shelves) {
			Walkway w = new Walkway();
			
			if ((c.getRow() - 1) >= 0 && mapElements[c.getRow() - 1][c.getCol()] != null && mapElements[c.getRow() - 1][c.getCol()] instanceof Walkway) {
				w = (Walkway) mapElements[c.getRow() - 1][c.getCol()];
			} else if ((c.getRow() + 1) < ts.dimension[1] && mapElements[c.getRow() + 1][c.getCol()] != null && mapElements[c.getRow() + 1][c.getCol()] instanceof Walkway) {
				w = (Walkway) mapElements[c.getRow() + 1][c.getCol()];
			}
			
			Shelf s = new Shelf("S" + k, c.getRow(), c.getCol(), w);
			
			mapElements[c.getRow()][c.getCol()] = s;
			
			k++;
		}
		
		//Create Aisle
		int r = 0;
		int c = -1;
		
		for (MapElement[] li: mapElements) {
			c = -1;
			int indexA = -1;
			int indexB = -1;
			
			for (int i = 0; i < li.length; i++) {
				if (li[i] instanceof Intersection) {
					indexA = indexB;
					indexB = i;
					
					if (indexA != -1) {
						c++;
						
						Aisle a = new Aisle(r, c, (Intersection)li[indexA], (Intersection)li[indexB]);
						aisles.add(a);
						
						for (int j = indexA + 1; j < indexB; j++) {
							if (li[j] instanceof Walkway) {
								((Walkway) li[j]).setAisle(a);
							}
						}
					}
				}
			}
			
			if (c != -1) {
				r++;
			}
		}
	}
	
	//Very Important, has all the important information in it
	//The walkways in aisle (-1,-1) is in the "imaginary" aisle that holds everything that are not in the horizontal aisles (which are vertical aisles)
	//Those that are in the imaginary aisle are the perpendicular aisles to the shelves, so they would be VerticalWkwys in the app
	//And the rest of them would be the HorizonalWkwys in the app
	//Finding the shelves where the product is saved can also be achieved by using this list
	public MapElement[][] getMapElements() {
		return mapElements;
	}
	
	//The aisles are critical to finding the shortest distance between any to product, that is the shelf that holds the product, and is the walkway where the customer would stand in and grab the item
	public ArrayList<Aisle> getAisles() {
		return aisles;
	}
	
	//Here the customer would send a list of products first, then through SQL, we would know which shelf each product is on, then we can know the name of the shelf (Or ID, could be changed)
	//If designed properly, there should be no imaginary shelves returned, but handling the exception would be just fine.
	public Shelf getShelf(String name) {
		Shelf s = new Shelf();
		
		for (MapElement[] mE: mapElements) {
			for (MapElement e: mE) {
				if (e.getName().equals(name)) {
					s = (Shelf) e; 
				}
			}
		}
		
		return s;
	}
}
