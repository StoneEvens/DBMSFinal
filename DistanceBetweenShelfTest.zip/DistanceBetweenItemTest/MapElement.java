
public class MapElement {
	protected int row, col;
	protected String name;
	
	public int getRow() {
		return row;
	}
	
	public int getCol() {
		return col;
	}
	
	public String getName() {
		return name;
	}
}
