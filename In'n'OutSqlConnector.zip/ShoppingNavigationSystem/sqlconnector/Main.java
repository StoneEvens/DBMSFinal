package sqlconnector;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
	static Scanner scnr = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			SqlConnector cctr = new SqlConnector();
			
			System.out.println(cctr.getStore("1"));
			
			for (String s: cctr.getShelf("1")) {
				System.out.println(s);
			}
			
			for (String s: cctr.getIntersection("1")) {
				System.out.println(s);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
