package sqlconnector;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class SqlConnector {
	private Connection conn;
	
	//Getters (Sql Commands)
	//store
	
	public SqlConnector () throws SQLException{
		String server = "jdbc:mysql://127.0.0.1:3306/";
		String database = "mydb"; // change to your own database
		String url = server + database + "?useSSL=false";
		String username = "employee";
		String password = "123456";
		
		this.conn = DriverManager.getConnection(url, username, password);
		System.out.println("DB connected");
	}
	
	
	public ArrayList<String> getStore(String Store_ID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;
		boolean success;
	
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Total_Row, Total_Col, Entrance_ID, Exit_ID FROM `Store` WHERE Store_ID = '%s'", Store_ID);
			
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				if (result.next()) {
					
					//Storeoutput = String.format("%s, %s, %s, %s", result.getString("Total_Row"), result.getString("Total_Col"), result.getString("Entrance_ID"), result.getString("Exit_ID"));
					resultList.add(result.getString("Total_Row"));
					resultList.add(result.getString("Total_Col"));
					resultList.add(result.getString("Entrance_ID"));
					resultList.add(result.getString("Exit_ID"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	
	//shelf	
	public ArrayList<String> getShelf(String Store_ID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;
		boolean success;
		
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Shelf_ID, AdjacentWalkway, `Col_No`, `Row_No` FROM `Shelf` WHERE `Store_ID` = '%s'", Store_ID);
				
				
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s, %s, %s, %s", result.getString("Shelf_ID"), result.getString("AdjacentWalkway"), result.getString("Row_No"), result.getString("Col_No")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	
	public String getTargetShelf(String storeID, String productName) {
		String query;
		String shelfID = "NotFound";
		
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT P.Shelf_ID FROM `Product` AS P JOIN Shelf ON P.Shelf_ID = Shelf.Shelf_ID WHERE P.Product_Name = '%s' AND Shelf.Store_ID = '%s'", productName, storeID);
			
			if (stat.execute(query)) {
				ResultSet result = stat.getResultSet();
				
				if (result.next()) {
					shelfID =  result.getString("Shelf_ID");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return shelfID;
	}
	
	//product	
	public ArrayList<String> getProduct(String ShelfID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;		
		
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT P.Product_Name FROM product AS P WHERE Shelf_ID = '%s'", ShelfID);
			
			if (stat.execute(query)) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s", result.getString("Product_Name")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	
	public ArrayList<String> getStoreProducts(String storeID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;		
		
		try (Statement stat = conn.createStatement()) {
			query = String.format("WITH t1 AS (SELECT P.Product_ID, P.Product_Name, P.Product_Price, P.Product_Description, S.store_id FROM Product AS P JOIN Shelf AS S ON P.Shelf_ID = S.Shelf_ID) SELECT P.Product_Name, P.Product_Price, P.Product_Description, ifnull(D.Discount, 0) AS Discount FROM t1 AS P LEFT OUTER JOIN product_promotion AS D ON P.Product_ID = D.Product_ID WHERE P.Store_id = %s", storeID);
				
			if (stat.execute(query)) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s/AND/%s/AND/%s/AND/%s", result.getString("Product_Name"), result.getString("Product_Price"), result.getString("Product_Description"), result.getString("Discount")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	
	//review	
	public ArrayList<String> getReview(String Product_ID, String Customer_ID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;
		boolean success;
			
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Review_Info FROM `Product_Review` WHERE Product_ID = '%s' AND Customer_ID = '%s'", Product_ID, Customer_ID);
					
					
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s", result.getString("Review_Info")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	
	//promotion	
	public String getPromotion(String Product_ID) {
		String Promotionoutput = "";
		String query;
		boolean success;
				
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Discount, Promotion_Date FROM `Product_Promotion` WHERE %s", Product_ID);
						
						
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				result.next();
				
				Promotionoutput = String.format("%s, %s", result.getString("Discount"), result.getString("Promotion_Date"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Promotionoutput;	
	}
	
	//history	
	public ArrayList<String> getHistory(String ProductName, String StoreID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;
		boolean success;
					
		try (Statement stat = conn.createStatement()) {
			query = String.format("WITH t1 AS (SELECT P.product_ID FROM product AS P JOIN Shelf AS S ON P.Shelf_ID = S.Shelf_ID WHERE P.product_name = '%s' AND S.Store_ID = %s) SELECT H.Price, date(H.Recorded_Time) AS Date FROM product_price_history AS H JOIN t1 ON H.Product_ID = t1.product_ID ORDER BY H.Recorded_Time", ProductName, StoreID);
				
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s/AND/%s", result.getString("Date"), result.getString("Price")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;		
	}
	
	//Customer	
	public String getCustomer(String Customer_ID, String Customer_Password) {
		String query;
		String name = "NotFound";
		boolean success;
						
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Customer_ID, User_ID FROM `Customer` WHERE Customer_ID = '%s' AND Password = '%s'", Customer_ID, Customer_Password);
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				if (result.next()) {
					name = result.getString("User_ID");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return name;	
	}
	
	public String getCustomer(String Customer_ID) {
		String query;
		String name = "NotFound";
		boolean success;
						
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Customer_ID, User_ID FROM `Customer` WHERE Customer_ID = '%s'", Customer_ID);
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				if (result.next()) {
					name = result.getString("User_ID");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		System.out.println(name);
		return name;	
	}
	
	public ArrayList<String> getUserComments(String Customer_ID) {
		String query;
		ArrayList<String> comment = new ArrayList<String>();
		boolean success;
						
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT P.Product_Name, R.Review_Info FROM product_review AS R JOIN product AS P ON R.product_ID = P.product_ID WHERE R.Customer_ID = '%s'", Customer_ID);
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					comment.add(String.format("%s/AND/%s", result.getString("Product_Name"), result.getString("Review_Info")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return comment;
	}
	
	public ArrayList<String> getHistoryCart(String Customer_ID) {
		String query;
		ArrayList<String> cart = new ArrayList<String>();
		boolean success;
						
		try (Statement stat = conn.createStatement()) {
			query = String.format("WITH t1 AS (SELECT P.Product_Name, H.Customer_ID FROM purchase_history AS H JOIN Product AS P ON H.Product_ID = P.Product_ID) SELECT Product_Name FROM t1 WHERE Customer_ID = '%s'", Customer_ID);
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					cart.add(result.getString("Product_Name"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return cart;
	}
	
	public ArrayList<String> getProductComments(String Product_Name, String Store_ID) {
		String query;
		ArrayList<String> comment = new ArrayList<String>();
		boolean success;
						
		try (Statement stat = conn.createStatement()) {
			query = String.format("WITH t1 AS (SELECT P.Product_ID, P.Product_Name, S.Store_ID FROM product AS P LEFT JOIN shelf AS S ON P.Shelf_ID = S.shelf_ID) SELECT R.Review_Info FROM product_review AS R JOIN t1 ON R.product_ID = t1.product_ID WHERE t1.Product_Name = '%s' AND t1.Store_ID = '%s'", Product_Name, Store_ID);
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					comment.add(String.format("%s", result.getString("Review_Info")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return comment;
	}
	
	//Intersection	
	public ArrayList<String> getIntersection(String Store_ID) {
		ArrayList<String> resultList = new ArrayList<String>();
		String query;
		boolean success;
							
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT Intersection_ID, Row_No, Col_No FROM `Intersection` WHERE Store_ID = '%s'", Store_ID);
					
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				while (result.next()) {
					resultList.add(String.format("%s, %s, %s", result.getString("Intersection_ID"), result.getString("Row_No"), result.getString("Col_No")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultList;	
	}
	
	//employee
	public boolean findEmployee(String Emp_ID) {
		String query = String.format("SELECT Employee_ID FROM Employee WHERE Employee_ID = %s", Emp_ID);
		boolean success;
		
		try (Statement stat = conn.createStatement()){
			success = stat.execute(query);
			
			if (success) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	//Setters (Sql Commands)
	//These may not be used
	public boolean writeComment(String Customer_ID, String Product_Name, String Store_ID, String comment) {
		String query = String.format("SELECT P.Product_ID FROM product AS P LEFT JOIN shelf AS S ON P.Shelf_ID = S.shelf_ID WHERE P.Product_Name = '%s' AND S.Store_ID = %s", Product_Name, Store_ID);
		boolean success;
		
		try (Statement stat = conn.createStatement()){
			success = stat.execute(query);
			
			if (success) {
				ResultSet result = stat.getResultSet();
				
				if (result.next()) {
					String productID = result.getString("Product_ID");
					System.out.println(productID);
					
					query = String.format("INSERT INTO product_review (Review_Info, Customer_ID, Product_ID) VALUES ('%s', '%s', %s)", comment, Customer_ID, productID);
					
					try (Statement stat2 = conn.createStatement()) {
						success = stat2.execute(query);
						
						return true;
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean updateHistoryCart(ArrayList<String> value) {
		String query = String.format("DELETE FROM purchase_history WHERE customer_id = '%s'", value.get(0));
		
		try (Statement stat = conn.createStatement()){
			stat.execute(query);
		} catch (SQLException e) {
			return false;
		}
		
		for (int i = 1; i < value.size(); i++) {
			String[] values = value.get(i).split("/AND/");
			query = String.format("SELECT product_id FROM PRODUCT WHERE shelf_id = %s AND product_name = '%s'", values[0], values[1]);
			
			try (Statement stat = conn.createStatement()) {
				boolean success = stat.execute(query);
				
				if (success) {
					ResultSet result = stat.getResultSet();
					
					if (result.next()) {
						String id = result.getString("Product_ID");
						
						query = String.format("INSERT INTO purchase_history (Customer_ID, Product_ID) VALUES ('%s', %s)", value.get(0), id);
						
						try (Statement stats = conn.createStatement()){
							stats.execute(query);
						} catch (SQLException e) {
							return false;
						}
					}
				}
			} catch (SQLException e) {
				
			}
		}
		
		return true;
	}
	
	//updateProduct
	public void updateProduct(String Shelf_ID, String Product_ID) {
		String query = String.format("UPDATE `Product` SET `Shelf_ID`='%s' WHERE Product__ID = '%s'", Shelf_ID, Product_ID);
			
		try (Statement stat = conn.createStatement()){
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//insertProduct	
	public void insertProduct(String Product_ID, String Shelf_ID, String Product_Name, String Product_Price, String Product_Description) {
		String query = String.format("INSERT INTO `Product`(`Product_ID`, `Shelf_ID`, `Product_Name`, `Product_Price`, `Product_Description`) VALUES ('%s', `%s`, `%s`, %d,`%s`)", Product_ID, Shelf_ID, Product_Name, Product_Price, Product_Description);
				
		try (Statement stat = conn.createStatement()){
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//updatePromotion
	public void updatePromotion(String Product_ID, int Discount, String Promotion_Date) {
		String query = String.format("UPDATE `Promotion` SET `Discount`= %d, `Promotion_Date = `%s`` WHERE Product__ID = '%s'", Discount, Promotion_Date, Product_ID);
					
		try (Statement stat = conn.createStatement()){
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//insertPromotion
	public void insertPromotion(String Product_ID, int Discount, String Promotion_Date) {
		String query = String.format("INSERT INTO `Promotion`(`Product_ID`, `Discount`, `Promotion_Date`) VALUES ('%s', %d,`%s`)", Product_ID, Discount, Promotion_Date);
				
		try (Statement stat = conn.createStatement()){
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void insertCustomer(String Customer_ID, String Customer_Password, String Customer_Name) {
		String query = String.format("INSERT INTO `Customer` VALUES ('%s', '%s', '%s')", Customer_ID, Customer_Name , Customer_Password);
		
		try (Statement stat = conn.createStatement()){
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}