import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class SqlManager {
	Connection conn;
	static Statement stat;
	private String columns;
	private String data;
	private String condition;
	private boolean login;
	
	public SqlManager () throws SQLException{
		String server = "jdbc:mysql://127.0.0.1:3306/";
		String database = "SAproject"; // change to your own database
		String url = server + database + "?useSSL=false";
		String username = "root";
		String password = "";
		
		this.conn = DriverManager.getConnection(url, username, password);
		System.out.println("DB connected");
			
		stat = conn.createStatement();
	}
	
	//The General SqlCommand
	private ArrayList<String[]> accessData(String table, String query) {
		ArrayList<String[]> list = new ArrayList<String[]>();
		
		try {
			Statement stat = conn.createStatement();
			
			if (stat.execute(query)) {
				ResultSet result = stat.getResultSet();
				
				String temp = "0";
				
				while (result.next()) {
					switch (table) {
					case ("Inventory"):
						temp = String.format("%sSPLIT%sSPLIT%sSPLIT%s", result.getString("ProductID"), result.getString("ProductName"), result.getString("Quantity"), result.getString("Stock"));
						break;
					case ("Sales"):
						temp = String.format("%sSPLIT%sSPLIT%sSPLIT%s", result.getString("TransactionID"), result.getString("ProductID"), result.getString("Amount"), result.getString("Date"));
						break;
					case ("Irregular"):
						temp = String.format("%sSPLIT%sSPLIT%sSPLIT%s", result.getString("TransactionID"), result.getString("ProductID"), result.getString("Amount"), result.getString("Date"));
						break;
					}
					
					//System.out.println(temp);
					list.add(temp.split("SPLIT"));
				}
				
				result.close();
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(new JFrame(), "Couldn't Perform Your SQL Command", "Error", JOptionPane.ERROR_MESSAGE);
		}
		
		return list;
	}
	
	//Getters (Sql Commands)
	public ArrayList<String[]> getData(String table, String column, String target) {
		return accessData(table, String.format("SELECT %s FROM `%s` WHERE %s", column, table, target));
	}
	
	public ArrayList<String[]> getData(String table, String column) {
		return accessData(table, String.format("SELECT %s FROM `%s`", column, table));
	}
	
	//Setters (Sql Commands)
	public void addInventory(String id, String name, String quantity) {
		accessData("Inventory", String.format("INSERT INTO `inventory`(`ProductID`, `ProductName`, `Quantity`, `Stock`) VALUES ('%s','%s','%s','%s')", id, name, quantity, quantity));
	}
	
	public void updateInventory(String target, String amount) {
		accessData("Inventory", String.format("UPDATE `inventory` SET `Stock`='%s' WHERE `ProductID`=%s", amount, target));
	}
	
	public void addSales(String tid, String pid, String amount, String date) {
		accessData("Sales", String.format("INSERT INTO `sales`(`TransactionID`, `ProductID`, `Amount`, `Date`) VALUES ('%s','%s','%s','%s')", tid, pid, amount, date));
	}
	
	public void updateSales(String target, String amount) {
		accessData("Sales", String.format("UPDATE `sales` SET `Amount`='%s' WHERE `ProductID`=%s", amount, target));
	}
	
	public void addIrregular(String tid, String pid, String amount, String date) {
		accessData("Irregular", String.format("INSERT INTO `irregular`(`TransactionID`, `ProductID`, `Amount`, `Date`) VALUES ('%s','%s','%s','%s')", tid, pid, amount, date));
	}
	
	public void clearData() {
		accessData("Inventory", "DELETE FROM `inventory`");
		accessData("Sales", "DELETE FROM `sales`");
		accessData("Irregular", "DELETE FROM `irregular`");
	}
	
	
	//The Original Functions
	/*
	public String search(String columns, String condition) {
		String output = "";
		String query;
		boolean success;
	
		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT %s FROM `irregulartransaction` WHERE %s", columns, condition);
	
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				
				if (result.next()) {
					String temp = String.format("Transaction ID: %s Product Name: %s Product ID: %s Date: %s", result.getString("ID"), result.getString("Product"), result.getString("ProductID"), result.getString("Date"));
					System.out.println(temp);
					result.close();
					return temp;
				} else {
					result.close();
					return "0";
				}
				
				//output = result.getString("Product");
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return output;
	}
	
	public void addData(String table, String columns, String data) {
		String query;
		
		try (PreparedStatement preparedStatement = conn.prepareStatement(
				"INSERT INTO `" + table + "` (" + columns + ") VALUES (" + data + ")")) {
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public void delete(String table,String condition) {
		String query;
		boolean success;
		query = String.format("DELETE FROM `%s` WHERE %s",table,condition);
		
		try {
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//input order
	public void insertPurchase(String date, int purchaseAmount, int inventoryAmount, int soldAmount, String soldDate) {
		String query = String.format("INSERT INTO `Purchase`(`Date`, `Purchase Amount`, `Inventory Amount`, `Sold Amount`, `Sold date`) " +
				"VALUES ('%s', %d, %d, %d, '%s')", date, purchaseAmount, inventoryAmount, soldAmount, soldDate);
	
		try {
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//如以下三個method要用其他來找String.format( "`Date` = %d",input)中的Date改就可
	//用日期來找發貨數量
	public String searchPurchaseAmount(int input) {
		String output = search("PurchaseAmount",String.format( "`Date` = %d",input));
		return output;
	}
	//用日期來找存貨數量
	public String searchInventoryAmount(int input) {
		String output = search("InventoryAmount",String.format( "`Date` = %d",input));
		return output;
	}

	//用日期來找銷售數量
	public String searchSoldAmount(int input) {
		String output = search("SoldAmount",String.format( "`Date` = %d",input));
		return output;
	}

	
	public static void updateInventory(int input, int date) {
        String query = String.format("UPDATE `Purchase` SET `Inventory Amount`='%d' WHERE `Date` = %d", input, date);

        try {
            stat.execute(query); 
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


	//input client
	public void insertClient(String paymentCode,  String boughtDate ,String goodsDate ) {
		String query = String.format("INSERT INTO `client`( `PaymentCode`, `BoughtDate`, `GoodsDate`) VALUES ('%s','%s','%s')", paymentCode, boughtDate, goodsDate);
	
		try {
			stat.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//透過paymentCode來取得商品發貨的日期
	public String getGoodsDate(String paymentCode){
		String output = "";
		String query;
		boolean success;

		try (Statement stat = conn.createStatement()) {
			query = String.format("SELECT %s FROM `client` WHERE `paymentCode` = %s","GoodsDate",paymentCode);
			
			success = stat.execute(query);
			if (success) {
				ResultSet result = stat.getResultSet();
				output = result.toString();
				result.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return output;
	}
	*/
}
