package com.example.dbms;



public class comment_item {


    }
